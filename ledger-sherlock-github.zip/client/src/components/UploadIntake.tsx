import { useMemo, useRef, useState, type DragEvent } from "react";
import { toast } from "sonner";
import { FileArchive, FileText, FolderUp, Image, Loader2, Music2, Trash2, UploadCloud, Video } from "lucide-react";
import { trpc } from "@/lib/trpc";

const MAX_FILE_BYTES = 10 * 1024 * 1024;
const MAX_BATCH_BYTES = 30 * 1024 * 1024;
const MAX_FILES = 3;
const BLOCKED_EXTENSIONS = new Set(["apk", "bat", "cmd", "com", "dll", "dmg", "exe", "jar", "msi", "ps1", "sh", "vbs"]);

function formatBytes(bytes: number) {
  return bytes < 1024 * 1024 ? `${Math.ceil(bytes / 1024)} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function fileCategory(file: File) {
  const extension = file.name.split(".").pop()?.toLowerCase() ?? "";
  if (["csv", "tsv", "xls", "xlsx", "json", "xml"].includes(extension)) return { label: "Tabular", Icon: FileText };
  if (file.type.startsWith("image/")) return { label: "Image", Icon: Image };
  if (file.type.startsWith("audio/")) return { label: "Audio", Icon: Music2 };
  if (file.type.startsWith("video/")) return { label: "Video", Icon: Video };
  if (["zip", "rar", "7z", "tar", "gz"].includes(extension)) return { label: "Archive", Icon: FileArchive };
  return { label: "Document", Icon: FileText };
}

function readFile(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Could not read ${file.name}`));
    reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
    reader.readAsDataURL(file);
  });
}

export function UploadIntake() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [dragging, setDragging] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const utils = trpc.useUtils();
  const upload = trpc.uploads.createBatch.useMutation({
    onSuccess: async (result) => {
      await utils.uploads.listBatches.invalidate();
      setFiles([]);
      setUploadError(null);
      toast.success(`Batch ${result.batchId} received · ${result.files.length} file${result.files.length === 1 ? "" : "s"} stored securely`);
    },
    onError: (error) => { const message = error.message || "Upload could not be completed"; setUploadError(message); toast.error(message); },
  });
  const batches = trpc.uploads.listBatches.useQuery(undefined, { retry: false });

  const totalBytes = useMemo(() => files.reduce((total, file) => total + file.size, 0), [files]);

  const addFiles = (incoming: FileList | File[]) => {
    const candidates = Array.from(incoming);
    const accepted: File[] = [];
    for (const file of candidates) {
      const extension = file.name.split(".").pop()?.toLowerCase() ?? "";
      if (BLOCKED_EXTENSIONS.has(extension)) { toast.error(`${file.name} is an executable or script file and cannot be uploaded`); continue; }
      if (file.size === 0) { toast.error(`${file.name} is empty`); continue; }
      if (file.size > MAX_FILE_BYTES) { toast.error(`${file.name} is larger than 10 MB`); continue; }
      accepted.push(file);
    }
    setFiles((existing) => {
      const next = [...existing, ...accepted].slice(0, MAX_FILES);
      if (existing.length + accepted.length > MAX_FILES) toast.error("A batch can contain up to 3 files");
      if (next.reduce((total, file) => total + file.size, 0) > MAX_BATCH_BYTES) { toast.error("A batch can contain up to 30 MB of files"); return existing; }
      return next;
    });
  };

  const submit = async () => {
    if (!files.length) { toast.error("Choose at least one file to upload"); return; }
    setUploadError(null);
    try {
      const encoded = await Promise.all(files.map(async (file) => ({ name: file.name, mimeType: file.type || "application/octet-stream", byteSize: file.size, contentBase64: await readFile(file) })));
      upload.mutate({ files: encoded });
    } catch (error) {
      const message = error instanceof Error ? error.message : "The selected files could not be read";
      setUploadError(message);
      toast.error(message);
    }
  };

  const onDrop = (event: DragEvent<HTMLDivElement>) => { event.preventDefault(); setDragging(false); addFiles(event.dataTransfer.files); };

  return <section id="live-upload-intake" className="upload-intake panel" aria-labelledby="upload-intake-title">
    <div className="panel-heading"><div><div className="section-label">Live ingestion</div><h2 id="upload-intake-title">Upload an actual reconciliation batch</h2><p>Your files are stored securely and registered to this workspace before processing.</p></div><span className="status-badge status-badge--success"><span className="status-badge__dot" />Secure account storage</span></div>
    <div className="intake-security-note">You can choose files now. Sign in is required only when you store the batch, which keeps uploaded records private to the workspace.</div>
    <div className={`intake-dropzone ${dragging ? "is-dragging" : ""}`} onDragEnter={(event) => { event.preventDefault(); setDragging(true); }} onDragOver={(event) => event.preventDefault()} onDragLeave={() => setDragging(false)} onDrop={onDrop}>
      <div className="intake-dropzone__icon"><FolderUp size={23} /></div><strong>Drop files here, or choose files</strong><span>CSV, Excel, PDF, images, audio, video, ZIP and other non-executable files</span><span className="intake-dropzone__limits">Up to 3 files · 10 MB each · 30 MB per batch</span><button type="button" className="button button--accent" onClick={() => inputRef.current?.click()}><UploadCloud size={15} /> Choose files</button><input ref={inputRef} className="sr-only" type="file" multiple onChange={(event) => { if (event.target.files) addFiles(event.target.files); event.currentTarget.value = ""; }} />
    </div>
    {files.length > 0 && <div className="intake-files">{files.map((file, index) => { const { Icon, label } = fileCategory(file); return <div className="intake-file" key={`${file.name}-${index}`}><span className="intake-file__icon"><Icon size={16} /></span><div><strong>{file.name}</strong><span>{label} · {formatBytes(file.size)}</span></div><button type="button" className="icon-button icon-button--tiny" aria-label={`Remove ${file.name}`} onClick={() => setFiles((items) => items.filter((_, itemIndex) => itemIndex !== index))}><Trash2 size={14} /></button></div>; })}</div>}
    <div className="intake-actions"><span>{files.length ? `${files.length} selected · ${formatBytes(totalBytes)} ready for secure storage` : "No files selected"}</span><button type="button" className="button button--dark" disabled={!files.length || upload.isPending} onClick={submit}>{upload.isPending ? <Loader2 className="spin" size={15} /> : <UploadCloud size={15} />}{upload.isPending ? "Uploading…" : "Store batch & continue"}</button></div>
    {uploadError && <div className="intake-error" role="alert"><span>{uploadError}</span><button type="button" className="button button--ghost button--compact" disabled={upload.isPending} onClick={submit}>Retry upload</button></div>}
    {batches.data?.length ? <div className="recent-batches"><div className="section-label">Recent received batches</div>{batches.data.slice(0, 3).map((batch) => <div key={batch.id}><span className="mono">BATCH {String(batch.id).padStart(4, "0")}</span><span>{batch.fileCount} file{batch.fileCount === 1 ? "" : "s"}</span><span className="status-badge status-badge--success"><span className="status-badge__dot" />{batch.status}</span></div>)}</div> : null}
  </section>;
}
