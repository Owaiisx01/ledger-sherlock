import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, CircleAlert, Download, FileWarning, Loader2, Play, ShieldCheck, Sparkles, Timer, XCircle } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import "./Track4ProofPanel.css";

const number = new Intl.NumberFormat("en-IN");

export function Track4ProofPanel() {
  const [selectedCase, setSelectedCase] = useState("M001");
  const run = trpc.track4.runEvaluation.useMutation({ onSuccess: () => toast.success("60-case evaluation completed from the synthetic ground-truth corpus") });
  const classify = trpc.track4.classifyResidualCases.useMutation({ onSuccess: () => toast.success("Bounded AI review completed; every recommendation still requires a human") });
  const packet = trpc.track4.getEscalationPacket.useQuery({ caseId: selectedCase });
  const result = run.data;

  const downloadPacket = () => {
    if (!packet.data) return;
    const content = JSON.stringify(packet.data, null, 2);
    const blob = new Blob([content], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${packet.data.caseId}-escalation-packet.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success("Escalation packet downloaded");
  };

  return <section className="track4-proof panel" aria-labelledby="track4-proof-title">
    <div className="track4-proof__header"><div><div className="section-label">Buildathon proof loop · synthetic ground truth</div><h2 id="track4-proof-title">Run the 60-case Finance Controller evaluation.</h2><p>This demo measures deterministic matching against versioned synthetic truth—not a cherry-picked transaction.</p><div className="track4-command-rail"><span><i /> Evidence inputs</span><span><i /> Deterministic rules</span><span><i /> Human gate</span></div></div><div className="track4-proof__targets"><span><ShieldCheck size={14} /> 60 cases</span><span><Timer size={14} /> Measured</span><span><FileWarning size={14} /> Honest exceptions</span></div></div>
    {!result && <div className={`track4-proof__empty ${run.isPending ? "is-running" : ""}`}><div><div className="track4-proof__mark">{run.isPending ? <Loader2 className="spin" size={20} /> : <Play size={20} />}</div><strong>{run.isPending ? "Building the measured decision trace." : "Ready to test the entire evidence chain."}</strong><p>{run.isPending ? "The system is comparing the versioned settlement, bank, and ERP evidence using fixed finance rules." : "40 exact, 7 fee/GST, 5 refund, 4 timing, and 4 unresolved cases across simulated settlement, bank and ERP inputs."}</p>{run.isPending && <div className="track4-run-sequence" aria-live="polite"><span><i /> Inputs sealed</span><span><i /> Rules applied</span><span><i className="is-working" /> Audit result preparing</span></div>}</div><button className="button button--accent" disabled={run.isPending} onClick={() => run.mutate()}>{run.isPending ? <Loader2 className="spin" size={15} /> : <Play size={15} />}{run.isPending ? "Running evaluated batch…" : "Run 60-case evaluation"}</button></div>}
    {result && <><motion.div className="track4-proof__result-band" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .22, ease: [0.23, 1, 0.32, 1] }}><span><CheckCircle2 size={14} /> Evaluation complete</span><strong>Versioned synthetic corpus · result sealed</strong><small>{result.metrics.durationMs}ms deterministic run</small></motion.div><div className="track4-scorecard"><div className="track4-score"><span>Cases processed</span><strong>{result.metrics.casesProcessed}</strong><small>{number.format(result.metrics.sourceRecords)} source records</small></div><div className="track4-score track4-score--citron"><span>Deterministic match rate</span><strong>{result.metrics.matchRate}%</strong><small>{result.metrics.autoClosed} auto-closed safely</small></div><div className="track4-score"><span>Decision accuracy</span><strong>{result.metrics.decisionAccuracy}%</strong><small>Against hidden ground truth</small></div><div className="track4-score track4-score--warm"><span>False-positive closes</span><strong>{result.metrics.falsePositiveAutoResolutions}</strong><small>Safety gate preserved</small></div><div className="track4-score"><span>Elapsed run</span><strong>{result.metrics.durationMs}ms</strong><small>{number.format(result.metrics.throughputPerSecond)} cases / sec</small></div></div>
      <div className="track4-split"><div className="track4-evidence"><div className="track4-subhead"><div><div className="section-label">Honest residual queue</div><h3>{result.metrics.unresolved} cases deliberately not auto-closed</h3></div><span className="status-badge status-badge--warning"><span className="status-badge__dot" /> Human decision required</span></div>{result.exceptions.map((item) => <button type="button" key={item.caseId} className={`track4-case ${selectedCase === item.caseId ? "is-selected" : ""}`} onClick={() => setSelectedCase(item.caseId)}><span className={`track4-case__icon ${item.decision === "escalation_ready" ? "is-red" : ""}`}>{item.decision === "escalation_ready" ? <CircleAlert size={15} /> : <FileWarning size={15} />}</span><span><strong>{item.caseId} · {item.reasonCode.replaceAll("_", " ")}</strong><small>{item.explanation}</small></span><span className="track4-case__confidence">{item.confidence}%<small>evidence</small></span></button>)}</div><aside className="track4-action"><div className="section-label">Escalation-ready evidence</div><h3>{selectedCase} case packet</h3><p>{packet.data?.recommendedNextStep ?? "Preparing the selected case packet…"}</p><div className="track4-evidence-list">{packet.data?.evidence.map((evidence) => <span key={evidence}><CheckCircle2 size={13} /> {evidence}</span>)}</div><button className="button button--dark button--full" disabled={packet.isLoading} onClick={downloadPacket}><Download size={15} /> Download escalation packet</button><small><ShieldCheck size={13} /> No money action, journal entry, or outbound message is automatic.</small></aside></div>
      <div className="track4-ai"><div><div className="section-label">Bounded AI investigation</div><h3>Classify the four residual cases after rules stop.</h3><p>AI is constrained to a fixed taxonomy, must cite source evidence, and cannot override policy or make a financial action.</p></div><button className="button button--ghost" disabled={classify.isPending} onClick={() => classify.mutate()}>{classify.isPending ? <Loader2 className="spin" size={15} /> : <Sparkles size={15} />}{classify.isPending ? "Classifying…" : "Run bounded AI review"}</button></div>
      <AnimatePresence>{classify.data && <motion.div className="track4-ai-results" initial="hidden" animate="visible" variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.06 } } }}>{classify.data.classifications.map((item) => <motion.div key={item.caseId} variants={{ hidden: { opacity: 0, y: 8 }, visible: { opacity: 1, y: 0, transition: { duration: 0.2, ease: [0.23, 1, 0.32, 1] } } }}><span>{item.caseId} · {item.confidence}%</span><strong>{item.reasonCode.replaceAll("_", " ")}</strong><p>{item.evidenceSummary}</p><small><XCircle size={12} /> Human approval required · {classify.data.source === "deterministic_fallback" ? "safe fallback" : "structured AI"}</small></motion.div>)}</motion.div>}</AnimatePresence>
    </>}
  </section>;
}
