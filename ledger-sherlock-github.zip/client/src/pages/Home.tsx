// Evidence Ledger style reminder for this page: warm paper surfaces, ink-charcoal hierarchy, Signal Citron active states, editorial asymmetry, and evidence-first interactions.
import { useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";
import { UploadIntake } from "@/components/UploadIntake";
import { Track4ProofPanel } from "@/components/Track4ProofPanel";
import "./MidnightLedger.css";
import "./NeonLedger.css";
import "./WinningConsole.css";
import {
  Activity,
  AlertCircle,
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Bell,
  BookOpen,
  BriefcaseBusiness,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  CircleDashed,
  ClipboardCheck,
  Clock3,
  CloudUpload,
  Database,
  Download,
  Eye,
  FileCheck2,
  FileClock,
  FileText,
  Filter,
  Gauge,
  GitBranch,
  History,
  Info,
  Layers3,
  LayoutDashboard,
  ListChecks,
  ListFilter,
  Loader2,
  Menu,
  MoreHorizontal,
  PanelLeftClose,
  PanelLeftOpen,
  PieChart,
  Play,
  Plus,
  RefreshCw,
  Scale,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Target,
  Upload,
  UserRound,
  Users,
  X,
  Zap,
} from "lucide-react";

const LOGO_URL = "/manus-storage/ledger-sherlock-mark_371e11a7.png";
const EVIDENCE_URL = "/manus-storage/ledger-sherlock-evidence-sheet_6ea0772a.png";
const SIGNAL_URL = "/manus-storage/ledger-sherlock-signal-grid_538b7379.png";
const CASEFILE_URL = "/manus-storage/ledger-sherlock-casefile_7a7db438.png";

type ViewKey =
  | "overview"
  | "reconciliation"
  | "exceptions"
  | "ai"
  | "validation"
  | "policy"
  | "audit"
  | "sources"
  | "analytics"
  | "settings";

type ExceptionRecord = {
  id: string;
  amount: string;
  source: string;
  issue: string;
  category: string;
  confidence: number;
  impact: string;
  status: string;
  tone: "amber" | "red" | "blue";
};

const navItems: { key: ViewKey; label: string; icon: any; group?: string }[] = [
  { key: "overview", label: "Overview", icon: LayoutDashboard },
  { key: "reconciliation", label: "Reconciliation", icon: GitBranch },
  { key: "exceptions", label: "Exceptions", icon: CircleAlert },
  { key: "ai", label: "AI Investigation", icon: Sparkles },
  { key: "validation", label: "Validation", icon: ClipboardCheck },
  { key: "policy", label: "Policy Engine", icon: ShieldCheck },
  { key: "audit", label: "Audit Trail", icon: History },
  { key: "sources", label: "Data Sources", icon: Database },
  { key: "analytics", label: "Analytics", icon: BarChart3 },
  { key: "settings", label: "Settings", icon: Settings2 },
];

const exceptions: ExceptionRecord[] = [
  {
    id: "ST_10482",
    amount: "₹48,500",
    source: "Razorpay",
    issue: "₹1,450 difference",
    category: "Fee variance",
    confidence: 94,
    impact: "High",
    status: "Review",
    tone: "amber",
  },
  {
    id: "ST_10491",
    amount: "₹22,000",
    source: "Razorpay",
    issue: "Duplicate settlement",
    category: "Duplicate settlement",
    confidence: 91,
    impact: "Medium",
    status: "Review",
    tone: "red",
  },
  {
    id: "ST_10502",
    amount: "₹8,400",
    source: "Bank",
    issue: "Delayed arrival",
    category: "Timing delay",
    confidence: 82,
    impact: "Medium",
    status: "Review",
    tone: "blue",
  },
  {
    id: "ST_10517",
    amount: "₹3,200",
    source: "ERP",
    issue: "Partial refund",
    category: "Partial refund",
    confidence: 78,
    impact: "Low",
    status: "Assigned",
    tone: "amber",
  },
];

const auditRows = [
  ["24 Aug · 10:42", "ST_10482", "Draft query", "₹100–₹5,000 rule", "Fee variance", "Not required", "System", "Completed"],
  ["24 Aug · 10:41", "ST_10491", "Escalated", "> ₹5,000 rule", "Duplicate settlement", "Required", "A. Sharma", "Pending"],
  ["24 Aug · 10:40", "ST_10502", "Assigned", "Review queue", "Timing delay", "Not required", "System", "Completed"],
  ["24 Aug · 10:38", "ST_10517", "Draft query", "₹100–₹5,000 rule", "Partial refund", "Not required", "System", "Completed"],
];

const sourceRows = [
  { name: "Razorpay Settlement", detail: "settlement_aug_24.csv", records: "1,247", sync: "Today · 10:39", type: "CSV upload", icon: BriefcaseBusiness },
  { name: "Bank Statement", detail: "hdfc_aug_24.csv", records: "1,239", sync: "Today · 10:40", type: "CSV upload", icon: FileText },
  { name: "ERP Ledger", detail: "tally_ledger_aug_24.csv", records: "1,251", sync: "Today · 10:40", type: "CSV upload", icon: Layers3 },
];

const pipelineSteps = [
  ["Data validation", "Schema + required columns"],
  ["Normalization", "Dates, currency, identifiers"],
  ["Deterministic matching", "Amount · reference · date"],
  ["Exception detection", "63 records surfaced"],
  ["AI investigation", "51 classifications ready"],
  ["Policy evaluation", "Bounded next actions"],
  ["Audit logging", "Traceable by default"],
];

function BrandLockup({ collapsed = false }: { collapsed?: boolean }) {
  return (
    <div className={`brand-lockup ${collapsed ? "brand-lockup--collapsed" : ""}`}>
      <div className="brand-mark-wrap">
        <img src={LOGO_URL} alt="Ledger Sherlock mark" className="brand-mark" />
      </div>
      {!collapsed && (
        <div className="brand-copy">
          <div className="brand-name">Ledger <span>Sherlock</span></div>
          <div className="brand-tagline">Reconcile faster. Investigate smarter.</div>
        </div>
      )}
    </div>
  );
}

function StatusBadge({ children, tone = "neutral", dot = true }: { children: ReactNode; tone?: "success" | "warning" | "danger" | "neutral" | "info"; dot?: boolean }) {
  return (
    <span className={`status-badge status-badge--${tone}`}>
      {dot && <span className="status-badge__dot" />}
      {children}
    </span>
  );
}

function SectionLabel({ children }: { children: ReactNode }) {
  return <div className="section-label">{children}</div>;
}

function MetricCard({ label, value, detail, icon: Icon, tone = "default", delta }: { label: string; value: string; detail: string; icon: any; tone?: "default" | "accent" | "warm" | "soft"; delta?: string }) {
  const evidenceStamp = { "Records processed": "B08 / 3 SRC", Matched: "DET / PASS", Exceptions: "QUEUE / 63", "Amount under review": "INR / OPEN" }[label] ?? "B08";
  return (
    <motion.div className={`metric-card metric-card--${tone}`} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }} whileHover={{ y: -2 }}>
      <div className="metric-card__top">
        <span className="metric-label">{label}</span>
        <span className="metric-icon"><Icon size={16} strokeWidth={1.8} /></span><span className="metric-card__stamp">{evidenceStamp}</span>
      </div>
      <div className="metric-card__value">{value}</div>
      <div className="metric-card__bottom">
        <span>{detail}</span>
        {delta && <span className="metric-delta"><ArrowUpRight size={13} /> {delta}</span>}
      </div>
      <div className="metric-signal"><i /><b /></div>
    </motion.div>
  );
}

function SourceCard({ name, records, status, icon: Icon, accent }: { name: string; records: string; status: string; icon: any; accent?: boolean }) {
  return (
    <div className={`source-card ${accent ? "source-card--accent" : ""}`}>
      <div className="source-card__top">
        <span className="source-icon"><Icon size={17} strokeWidth={1.8} /></span>
        <StatusBadge tone="success">{status}</StatusBadge>
      </div>
      <div className="source-card__name">{name}</div>
      <div className="source-card__meta"><span>{records} records</span><span>Synced 10:40</span></div>
      <div className="source-card__line"><span /><span /></div>
    </div>
  );
}

function EvidenceCommandCanvas({ onRun, onOpenQueue }: { onRun: () => void; onOpenQueue: () => void }) {
  return (
    <motion.section
      className="evidence-command-canvas"
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.34, ease: [0.23, 1, 0.32, 1] }}
    >
      <div className="canvas-noise" aria-hidden="true" />
      <header className="canvas-topline">
        <div className="canvas-batch-id"><span className="canvas-live-dot" /> BATCH 08 <i /> RECONCILIATION CONTROL</div>
        <div className="canvas-topline__right"><span>24 AUG 2026</span><StatusBadge tone="success">System ready</StatusBadge></div>
      </header>
      <div className="canvas-intro">
        <div>
          <SectionLabel>Finance operations · Owais Khan</SectionLabel>
          <h2>1,184 records closed.<br /><em>12 decisions need a human.</em></h2>
        </div>
        <p>Ledger Sherlock compares settlement, bank, and ERP evidence first. Only contradictions enter the review queue.</p>
      </div>
      <div className="canvas-workspace">
        <div className="evidence-sources">
          <div className="canvas-column-label"><span>01</span> Evidence received</div>
          {[
            ["Settlement export", "1,247", "RP", "10:39"],
            ["Bank credits", "1,239", "BK", "10:40"],
            ["ERP ledger", "1,251", "ERP", "10:40"],
          ].map(([name, count, code, time], index) => (
            <motion.div className="evidence-source" key={name} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: .1 + index * .06, duration: .25 }}>
              <span className="evidence-source__code">{code}</span>
              <div><strong>{name}</strong><span>{count} records · synced {time}</span></div>
              <CheckCircle2 size={15} />
            </motion.div>
          ))}
          <div className="evidence-source__note"><span /> 3 source files passed schema checks</div>
        </div>
        <div className="match-core">
          <div className="canvas-column-label"><span>02</span> Deterministic matching</div>
          <div className="match-core__trace">
            <div className="trace-heading"><span>Evidence trace</span><span>RULE SET / 04</span></div>
            <div className="trace-row"><span className="trace-row__source">RP</span><code>setl_9981</code><i /><b>₹48,500</b><small>REF exact</small></div>
            <div className="trace-row"><span className="trace-row__source trace-row__source--bank">BK</span><code>hdfc_4418</code><i /><b>₹47,050</b><small>fee + GST</small></div>
            <div className="trace-row"><span className="trace-row__source trace-row__source--erp">ERP</span><code>inv_10582</code><i /><b>₹48,500</b><small>ledger base</small></div>
            <div className="trace-decision"><span><CheckCircle2 size={15} /> Resolved by rule</span><strong>REFERENCE + FEE CHECK</strong><small>Evidence attached to audit log</small></div>
          </div>
          <div className="match-core__statement"><span>Matching is deterministic</span><strong>AI sees unresolved evidence only.</strong></div>
        </div>
        <div className="outcome-rail">
          <div className="canvas-column-label"><span>03</span> Controlled outcomes</div>
          <button className="outcome-card outcome-card--closed" onClick={onRun}>
            <span className="outcome-card__eyebrow"><CheckCircle2 size={14} /> Cleared automatically</span>
            <strong>1,184</strong>
            <small>94.96% match rate</small>
            <i className="outcome-card__arrow"><ChevronRight size={17} /></i>
          </button>
          <button className="outcome-card outcome-card--review" onClick={onOpenQueue}>
            <span className="outcome-card__eyebrow"><CircleAlert size={14} /> Human review</span>
            <strong>12</strong>
            <small>High-signal decisions</small>
            <i className="outcome-card__arrow"><ChevronRight size={17} /></i>
          </button>
          <div className="outcome-audit"><ShieldCheck size={14} /><span><b>100%</b> action traceability</span></div>
        </div>
      </div>
      <footer className="canvas-footer">
        <div className="canvas-footer__proof"><span>Proof status</span><b>3/3 inputs verified</b><i /><b>0 unsafe auto-actions</b></div>
        <div className="canvas-footer__actions"><button className="button button--ghost" onClick={onOpenQueue}>Open review queue <ChevronRight size={15} /></button><button className="button button--accent" onClick={onRun}><RefreshCw size={15} /> Run controlled match</button></div>
      </footer>
    </motion.section>
  );
}

function PageHeading({ eyebrow, title, subtitle, actions }: { eyebrow?: string; title: string; subtitle: string; actions?: ReactNode }) {
  return (
    <div className="page-heading">
      <div>
        {eyebrow && <SectionLabel>{eyebrow}</SectionLabel>}
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
      {actions && <div className="page-heading__actions">{actions}</div>}
    </div>
  );
}

function MiniChart({ accent = "citron", type = "line" }: { accent?: "citron" | "sage" | "terracotta"; type?: "line" | "bars" }) {
  if (type === "bars") {
    return (
      <div className={`mini-chart mini-chart--bars mini-chart--${accent}`} aria-label="classification distribution chart">
        {[46, 62, 38, 71, 53, 86, 66, 78, 57, 91, 74, 81].map((height, i) => <span key={i} style={{ height: `${height}%` }} />)}
      </div>
    );
  }
  return (
    <div className={`mini-chart mini-chart--${accent}`} aria-label="trend chart">
      <svg viewBox="0 0 360 96" preserveAspectRatio="none" role="img">
        <path className="chart-fill" d="M0,80 C32,76 47,60 70,66 C92,72 103,51 128,55 C157,59 171,34 194,44 C218,55 236,18 261,30 C287,43 295,25 326,22 C340,20 351,10 360,8 L360,96 L0,96 Z" />
        <path className="chart-line" d="M0,80 C32,76 47,60 70,66 C92,72 103,51 128,55 C157,59 171,34 194,44 C218,55 236,18 261,30 C287,43 295,25 326,22 C340,20 351,10 360,8" />
      </svg>
      <div className="chart-axis"><span>18 Aug</span><span>21 Aug</span><span>24 Aug</span></div>
    </div>
  );
}

function ConfidenceIndicator({ value = 94, compact = false }: { value?: number; compact?: boolean }) {
  return (
    <div className={`confidence ${compact ? "confidence--compact" : ""}`}>
      <div className="confidence__ring" style={{ "--confidence": `${value * 3.6}deg` } as CSSProperties}><span>{value}%</span></div>
      {!compact && <div><div className="confidence__label">AI confidence</div><div className="confidence__note">Classification signal</div></div>}
    </div>
  );
}

function Pipeline({ progress = 100, running = false }: { progress?: number; running?: boolean }) {
  return (
    <div className="pipeline-list">
      {pipelineSteps.map(([title, detail], index) => {
        const threshold = (index + 1) * 14;
        const completed = progress >= threshold + 2;
        const active = running && !completed && progress >= threshold - 14;
        return (
          <div className={`pipeline-row ${completed ? "is-complete" : ""} ${active ? "is-active" : ""}`} key={title}>
            <div className="pipeline-marker">{completed ? <Check size={13} /> : active ? <Loader2 size={13} className="spin" /> : <span>{index + 1}</span>}</div>
            <div className="pipeline-copy"><strong>{title}</strong><span>{detail}</span></div>
            <span className="pipeline-state">{completed ? "Completed" : active ? "Running" : "Pending"}</span>
          </div>
        );
      })}
    </div>
  );
}

function ExceptionTable({ onSelect, limit }: { onSelect: (record: ExceptionRecord) => void; limit?: number }) {
  const rows = limit ? exceptions.slice(0, limit) : exceptions;
  return (
    <div className="table-frame">
      <div className="data-table-wrap">
        <table className="data-table">
          <thead><tr><th>Record</th><th>Amount</th><th>Source</th><th>Detected issue</th><th>AI category</th><th>Confidence</th><th>Impact</th><th>Status</th><th /></tr></thead>
          <tbody>
            {rows.map((record) => (
              <tr key={record.id} onClick={() => onSelect(record)}>
                <td><span className="mono strong">{record.id}</span><span className="cell-sub">24 Aug · batch 08</span></td>
                <td className="amount-cell">{record.amount}</td>
                <td>{record.source}</td>
                <td>{record.issue}</td>
                <td><span className="category-chip">{record.category}</span></td>
                <td><span className="confidence-number">{record.confidence}%</span></td>
                <td><span className={`impact impact--${record.tone}`}>{record.impact}</span></td>
                <td><StatusBadge tone={record.status === "Assigned" ? "info" : "warning"}>{record.status}</StatusBadge></td>
                <td><button className="icon-button icon-button--tiny" aria-label={`Open ${record.id}`}><ChevronRight size={15} /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AIInvestigationCard({ onConfidence }: { onConfidence: () => void }) {
  return (
    <div className="ai-card">
      <div className="ai-card__header">
        <div><SectionLabel>AI Exception Classifier</SectionLabel><h3>AI Investigation</h3></div>
        <span className="ai-badge"><Sparkles size={13} /> Ledger Sherlock AI</span>
      </div>
      <div className="ai-card__grid">
        <div className="ai-card__field"><span>Classification</span><strong>Fee variance</strong></div>
        <button className="ai-card__field ai-card__field--button" onClick={onConfidence}><span>Confidence <Info size={13} /></span><strong>94%</strong><small>Click to see basis</small></button>
      </div>
      <div className="ai-explanation"><span className="ai-explanation__label">Explanation</span><p>The settlement amount differs from the ERP amount by ₹1,450. The difference is consistent with a payment processing fee.</p></div>
      <div className="ai-action"><div><span className="ai-explanation__label">Suggested action</span><strong>Verify the settlement fee against the merchant fee configuration.</strong></div><button className="subtle-button" onClick={() => toast.success("Draft query staged for review")}>Draft query <ArrowUpRight size={14} /></button></div>
      <div className="ai-disclaimer"><ShieldCheck size={14} /> AI classification is based on the unresolved exception context produced by the deterministic matching engine.</div>
    </div>
  );
}

function ApprovalCard() {
  return (
    <div className="approval-card">
      <div className="approval-card__icon"><ShieldCheck size={18} /></div>
      <div className="approval-card__body"><SectionLabel>Control gate</SectionLabel><h3>Human approval required</h3><p>Amount exceeds the automated action threshold. AI cannot bypass this control.</p><div className="approval-card__meta"><span>Policy: &gt; ₹5,000</span><span>Owner: Finance Ops</span></div></div>
      <div className="approval-card__actions"><button className="button button--dark" onClick={() => toast.success("Approval recorded for review")}>Approve action</button><button className="button button--ghost" onClick={() => toast("Action rejected and logged")}>Reject</button><button className="button button--text" onClick={() => toast("Reviewer assignment opened")}>Assign to reviewer</button></div>
    </div>
  );
}

export default function Home() {
  const [activeView, setActiveView] = useState<ViewKey>(() => {
    const requestedView = new URLSearchParams(window.location.search).get("view");
    return navItems.some((item) => item.key === requestedView) ? requestedView as ViewKey : "overview";
  });
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(78);
  const [selectedException, setSelectedException] = useState<ExceptionRecord | null>(null);
  const [confidenceOpen, setConfidenceOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [merchantOpen, setMerchantOpen] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [commandQuery, setCommandQuery] = useState("");
  const commandInputRef = useRef<HTMLInputElement>(null);
  const [activeFilter, setActiveFilter] = useState("All");
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!running) return;
    const timer = window.setInterval(() => {
      setProgress((value) => {
        if (value >= 100) {
          window.clearInterval(timer);
          setRunning(false);
          toast.success("Reconciliation complete · 1,184 records matched");
          return 100;
        }
        return value + 2;
      });
    }, 550);
    return () => window.clearInterval(timer);
  }, [running]);

  useEffect(() => {
    const handleShortcut = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setCommandOpen(true);
      }
      if (event.key === "Escape") {
        setCommandOpen(false);
        setMerchantOpen(false);
        setNotificationsOpen(false);
      }
    };
    window.addEventListener("keydown", handleShortcut);
    return () => window.removeEventListener("keydown", handleShortcut);
  }, []);

  useEffect(() => {
    if (commandOpen) {
      window.requestAnimationFrame(() => commandInputRef.current?.focus());
    }
  }, [commandOpen]);

  const filteredExceptions = useMemo(() => {
    return exceptions.filter((record) => {
      const matchesFilter = activeFilter === "All" || record.category === activeFilter;
      const query = search.toLowerCase();
      return matchesFilter && (!query || `${record.id} ${record.category} ${record.issue}`.toLowerCase().includes(query));
    });
  }, [activeFilter, search]);

  const go = (view: ViewKey) => {
    setActiveView(view);
    setMobileNavOpen(false);
  };

  const startReconciliation = () => {
    setProgress(78);
    setRunning(true);
    setActiveView("reconciliation");
    toast("Reconciliation started · deterministic engine is processing");
  };

  const renderOverview = () => (
    <>
      <PageHeading eyebrow="Evidence desk · Batch 08 · 24 Aug 2026" title="Reconciliation, under control." subtitle="A decision workspace for settlement evidence—not another black-box finance dashboard." actions={<button className="button button--ghost" onClick={() => go("sources")}><Upload size={15} /> Add evidence</button>} />
      <EvidenceCommandCanvas onRun={startReconciliation} onOpenQueue={() => go("exceptions")} />
      <div className="metric-grid metric-grid--proof">
        <MetricCard label="Records processed" value="1,247" detail="Across 3 sources" icon={FileCheck2} delta="+8.2%" />
        <MetricCard label="Matched" value="1,184" detail="94.96% match rate" icon={CheckCircle2} tone="accent" delta="+2.1%" />
        <MetricCard label="Exceptions" value="63" detail="Require investigation" icon={CircleAlert} tone="warm" />
        <MetricCard label="Amount under review" value="₹8,42,500" detail="Across unresolved exceptions" icon={Scale} tone="soft" />
      </div>
      <div className="overview-grid overview-grid--command">
        <div className="panel panel--pipeline"><div className="panel-heading"><div><SectionLabel>System path</SectionLabel><h2>From source to audit trail</h2></div><StatusBadge tone="success">Operational</StatusBadge></div><div className="flow-strip"><span>CSV sources</span><ChevronRight size={14} /><span>Deterministic engine</span><ChevronRight size={14} /><span>AI exceptions</span><ChevronRight size={14} /><span>Policy gate</span><ChevronRight size={14} /><span>Audit log</span></div><Pipeline progress={100} /></div>
        <div className="panel panel--signal"><div className="panel-heading"><div><SectionLabel>Review queue</SectionLabel><h2>Signal snapshot</h2></div><button className="icon-button" onClick={() => go("exceptions")} aria-label="View exception queue"><ArrowUpRight size={16} /></button></div><div className="signal-stat"><div><span className="signal-stat__number">12</span><span className="signal-stat__label">Require human review</span></div><div className="signal-stat__trend"><ArrowDownRight size={14} /> 4 from last run</div></div><MiniChart accent="citron" /><div className="signal-list"><div><span className="signal-dot signal-dot--amber" /> Fee variance <strong>7</strong></div><div><span className="signal-dot signal-dot--red" /> Duplicate settlement <strong>2</strong></div><div><span className="signal-dot signal-dot--blue" /> Timing delay <strong>3</strong></div></div></div>
      </div>
      <div className="section-row"><div><SectionLabel>Latest exceptions</SectionLabel><h2>Review the records that still need a human call.</h2></div><button className="button button--text" onClick={() => go("exceptions")}>View all exceptions <ChevronRight size={15} /></button></div>
      <ExceptionTable onSelect={setSelectedException} limit={3} />
    </>
  );

  const renderReconciliation = () => (
    <>
      <PageHeading eyebrow="Track 4 · evaluated finance-operations loop" title="Reconciliation" subtitle="Run a measured 60-case synthetic batch across settlement, bank and ERP evidence." actions={<><button className="button button--ghost" onClick={() => go("sources")}><Upload size={15} /> Upload data</button><button className="button button--accent" onClick={() => document.getElementById("track4-proof-title")?.scrollIntoView({ behavior: "smooth", block: "start" })}><Play size={15} /> Run evaluated batch</button></>} />
      <div className="source-grid"><SourceCard name="Settlement export" records="60 cases" status="Ground truth" icon={BriefcaseBusiness} accent /><SourceCard name="Bank-credit window" records="54 credits" status="Evaluated" icon={FileText} /><SourceCard name="ERP ledger" records="60 entries" status="Evaluated" icon={Layers3} /></div><Track4ProofPanel />
    </>
  );

  const renderExceptions = () => (
    <>
      <PageHeading eyebrow="Exception queue · 63 open" title="Exceptions" subtitle="Records that could not be confidently reconciled automatically." actions={<><button className="button button--ghost" onClick={() => toast("Exception export prepared") }><Download size={15} /> Export queue</button><button className="button button--accent" onClick={() => go("sources")}><Plus size={15} /> Add data</button></>} />
      <div className="filter-bar"><div className="filter-pills">{["All", "Fee variance", "Duplicate settlement", "Partial refund", "Timing delay"].map((filter) => <button key={filter} className={`filter-pill ${activeFilter === filter ? "is-active" : ""}`} onClick={() => setActiveFilter(filter)}>{filter}{filter === "All" && <span>63</span>}</button>)}</div><div className="filter-actions"><div className="table-search"><Search size={15} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search records" /></div><button className="button button--ghost button--compact"><SlidersHorizontal size={15} /> Filters</button></div></div>
      <div className="exception-summary"><div><span className="summary-label">Showing</span><strong>{filteredExceptions.length} records</strong><span className="summary-sub">Filtered from 63 unresolved</span></div><div className="summary-rule" /><div><span className="summary-label">Amount under review</span><strong>₹8,42,500</strong><span className="summary-sub">Across current batch</span></div><div className="summary-rule" /><div><span className="summary-label">AI classified</span><strong>51 / 63</strong><span className="summary-sub">81% context coverage</span></div></div>
      <ExceptionTable onSelect={setSelectedException} />
      <div className="empty-hint"><CircleDashed size={16} /><span>All records in this batch have a traceable state. New exceptions will appear here after the next deterministic run.</span></div>
    </>
  );

  const renderAI = () => (
    <>
      <PageHeading eyebrow="Investigation layer" title="AI Investigation" subtitle="AI classifies unresolved records after deterministic matching—not instead of it." actions={<button className="button button--ghost" onClick={() => setConfidenceOpen(true)}><Info size={15} /> How confidence works</button>} />
      <div className="ai-layout"><div><AIInvestigationCard onConfidence={() => setConfidenceOpen(true)} /><div className="panel pattern-panel"><div className="panel-heading"><div><SectionLabel>Pattern detection</SectionLabel><h2>Detected patterns</h2></div><StatusBadge tone="info">7 signals</StatusBadge></div><div className="pattern-card"><div className="pattern-card__icon"><GitBranch size={18} /></div><div className="pattern-card__copy"><h3>Possible systemic fee variance</h3><p>Three or more similar exceptions were identified with confidence above the configured threshold.</p><div className="pattern-card__meta"><span>7 exceptions</span><span>Average confidence: 91%</span><StatusBadge tone="warning">Pattern detected</StatusBadge></div></div></div><div className="pattern-card pattern-card--isolated"><div className="pattern-card__icon"><Target size={18} /></div><div className="pattern-card__copy"><h3>Isolated case</h3><p>Insufficient sample to classify as systemic.</p><div className="pattern-card__meta"><span>1 exception</span><span>Confidence: 78%</span><StatusBadge tone="neutral">Monitor</StatusBadge></div></div></div></div></div><div className="ai-side"><div className="panel ai-side__confidence"><div className="panel-heading"><div><SectionLabel>Confidence signal</SectionLabel><h2>94% AI confidence</h2></div><Sparkles size={17} className="accent-icon" /></div><ConfidenceIndicator /><div className="confidence-basis"><span>Based on</span><div><Check size={14} /> Exception pattern</div><div><Check size={14} /> Historical labeled examples</div><div><Check size={14} /> Available transaction context</div><div><Check size={14} /> Classification consistency</div></div><button className="button button--ghost button--full" onClick={() => setConfidenceOpen(true)}>View confidence explanation <ChevronRight size={15} /></button></div><div className="panel signal-image"><img src={SIGNAL_URL} alt="Abstract ledger signal grid" /><div className="signal-image__overlay"><SectionLabel>Deterministic first</SectionLabel><strong>51 exceptions<br />ready for context.</strong></div></div></div></div>
      <ApprovalCard />
    </>
  );

  const renderValidation = () => (
    <>
      <PageHeading eyebrow="Measured performance" title="Model Validation" subtitle="Measure the system against a hidden ground-truth dataset." actions={<StatusBadge tone="success">Test set verified · 250 records</StatusBadge>} />
      <div className="metric-grid validation-metrics"><MetricCard label="Precision" value="91.8%" detail="Measured on labeled set" icon={Target} tone="accent" /><MetricCard label="Recall" value="88.4%" detail="Measured on labeled set" icon={Gauge} tone="soft" /><MetricCard label="False positives" value="6" detail="Of 250 test records" icon={CircleAlert} tone="warm" /><MetricCard label="Test records" value="250" detail="Hidden ground truth" icon={ClipboardCheck} /></div>
      <div className="validation-grid"><div className="panel"><div className="panel-heading"><div><SectionLabel>Ground truth comparison</SectionLabel><h2>Predicted vs actual classifications</h2></div><button className="icon-button" onClick={() => toast("Validation report downloaded")} aria-label="Download validation report"><Download size={16} /></button></div><div className="validation-chart"><div className="chart-legend"><span><i className="legend-dot legend-dot--dark" /> Actual</span><span><i className="legend-dot legend-dot--citron" /> Predicted</span></div><div className="bar-chart">{[[68,74,"Fee variance"],[42,51,"Duplicate"],[35,29,"Timing delay"],[21,25,"Partial refund"],[15,11,"Unknown"]].map(([actual, predicted, label]) => <div className="bar-row" key={String(label)}><span>{label}</span><div className="bar-track"><i style={{ width: `${Number(actual)}%` }} /><b style={{ width: `${Number(predicted)}%` }} /></div><strong>{predicted}/{actual}</strong></div>)}</div></div><div className="validation-disclaimer"><Info size={15} /> These metrics are calculated from the labeled test set and are not AI self-reported confidence scores.</div></div><div className="panel validation-table-panel"><div className="panel-heading"><div><SectionLabel>Category scorecard</SectionLabel><h2>Measured outcomes</h2></div></div><div className="score-list">{[["Fee variance","31","28","28","3","90.3%","90.3%"],["Duplicate settlement","18","20","17","1","94.4%","85.0%"],["Timing delay","12","10","9","1","75.0%","90.0%"],["Partial refund","8","7","6","1","75.0%","85.7%"]].map((row) => <div className="score-row" key={row[0]}><strong>{row[0]}</strong><span><em>Predicted</em>{row[1]}</span><span><em>Actual</em>{row[2]}</span><span><em>Correct</em>{row[3]}</span><span><em>Incorrect</em>{row[4]}</span><span><em>Precision</em>{row[5]}</span><span><em>Recall</em>{row[6]}</span></div>)}</div></div></div>
      <div className="comparison-section"><div className="section-row"><div><SectionLabel>Architecture comparison</SectionLabel><h2>Why the layered architecture matters</h2><p>Benchmark not yet executed. The comparison below describes system behavior, not fabricated results.</p></div></div><div className="comparison-grid"><div className="comparison-card comparison-card--naive"><div className="comparison-card__head"><div className="comparison-mark">N</div><div><h3>Naive LLM approach</h3><span>Unbounded numeric reasoning</span></div></div>{["Sends complete dataset to LLM","LLM performs numeric matching","No deterministic matching","No calibrated validation","No bounded actions"].map((item) => <div className="comparison-item" key={item}><X size={14} />{item}</div>)}<div className="benchmark-state"><span>Benchmark status</span><strong>Not yet executed</strong></div></div><div className="comparison-card comparison-card--ledger"><div className="comparison-card__head"><div className="comparison-mark"><img src={LOGO_URL} alt="" /></div><div><h3>Ledger Sherlock</h3><span>Evidence-first control plane</span></div></div>{["Deterministic numeric matching","AI only investigates exceptions","Ground-truth validation","Policy-controlled actions","Complete audit trail"].map((item) => <div className="comparison-item" key={item}><Check size={14} />{item}</div>)}<div className="benchmark-state"><span>Benchmark status</span><strong>Not yet executed</strong></div></div></div></div>
    </>
  );

  const renderPolicy = () => (
    <>
      <PageHeading eyebrow="Control system" title="Policy Engine" subtitle="Bounded rules determine what the system can resolve automatically." actions={<button className="button button--accent" onClick={() => toast("Policy editor is ready for the backend connection") }><Plus size={15} /> Add policy</button>} />
      <div className="policy-banner"><div className="policy-banner__icon"><ShieldCheck size={20} /></div><div><strong>Every action has a boundary.</strong><p>Ledger Sherlock routes decisions according to amount, confidence, and approval requirements.</p></div><StatusBadge tone="success">3 active rules</StatusBadge></div>
      <div className="policy-grid"><div className="policy-card policy-card--low"><div className="policy-card__top"><span className="policy-index">01</span><StatusBadge tone="success">Auto-resolve</StatusBadge></div><h2>Low-value mismatch</h2><div className="policy-amount">&lt; ₹100</div><div className="policy-rule"><span>Action</span><strong>Auto-resolve</strong></div><div className="policy-rule"><span>Human approval</span><strong>Not required</strong></div><button className="button button--ghost button--full" onClick={() => toast("Low-value policy selected")}>Review rule <ChevronRight size={15} /></button></div><div className="policy-card policy-card--mid"><div className="policy-card__top"><span className="policy-index">02</span><StatusBadge tone="warning">Draft query</StatusBadge></div><h2>Medium-value mismatch</h2><div className="policy-amount">₹100 – ₹5,000</div><div className="policy-rule"><span>Action</span><strong>Draft query</strong></div><div className="policy-rule"><span>Human approval</span><strong>Required before sending</strong></div><button className="button button--ghost button--full" onClick={() => toast("Medium-value policy selected")}>Review rule <ChevronRight size={15} /></button></div><div className="policy-card policy-card--high"><div className="policy-card__top"><span className="policy-index">03</span><StatusBadge tone="danger">Human review only</StatusBadge></div><h2>High-value mismatch</h2><div className="policy-amount">&gt; ₹5,000</div><div className="policy-rule"><span>Action</span><strong>Human review only</strong></div><div className="policy-rule"><span>Automatic action</span><strong>Disabled</strong></div><button className="button button--dark button--full" onClick={() => go("exceptions")}>Open approval queue <ChevronRight size={15} /></button></div></div>
      <ApprovalCard />
    </>
  );

  const renderAudit = () => (
    <>
      <PageHeading eyebrow="Traceability layer" title="Audit Trail" subtitle="Every action is traceable from source record to policy decision." actions={<><button className="button button--ghost" onClick={() => toast("Audit export prepared") }><Download size={15} /> Export log</button><button className="button button--accent" onClick={() => toast("Audit filters opened") }><Filter size={15} /> Filter log</button></>} />
      <div className="audit-summary"><div><span>Actions logged</span><strong>1,312</strong><small>Across this workspace</small></div><div><span>Automated</span><strong>1,184</strong><small>Deterministic matches</small></div><div><span>Human decisions</span><strong>12</strong><small>Approval queue</small></div><div><span>Coverage</span><strong>100%</strong><small>Traceable by default</small></div></div>
      <div className="table-frame table-frame--audit"><div className="audit-table-wrap"><table className="data-table audit-table"><thead><tr>{["Timestamp","Record ID","Action","Rule triggered","AI classification","Human approval","User","Status"].map((header) => <th key={header}>{header}</th>)}</tr></thead><tbody>{auditRows.map((row, i) => <tr key={i}>{row.map((cell, index) => <td key={index}>{index === 1 ? <span className="mono strong">{cell}</span> : index === 7 ? <StatusBadge tone={cell === "Pending" ? "warning" : "success"}>{cell}</StatusBadge> : index === 6 ? <span className="user-cell"><span className="avatar avatar--tiny">{cell === "System" ? "S" : "AS"}</span>{cell}</span> : cell}</td>)}</tr>)}</tbody></table></div></div>
      <div className="audit-note"><FileClock size={17} /><div><strong>Immutable event history</strong><span>System, AI, policy, and human approvals write to the same timeline. Backend signing will be connected when the matching service is enabled.</span></div></div>
    </>
  );

  const renderSources = () => (
    <>
      <PageHeading eyebrow="Connected inputs" title="Data Sources" subtitle="Manage the files and feeds that power every reconciliation run." actions={<button className="button button--accent" onClick={() => document.getElementById("live-upload-intake")?.scrollIntoView({ behavior: "smooth", block: "start" })}><Upload size={15} /> Upload new dataset</button>} />
      <div className="source-management-list">{sourceRows.map(({ name, detail, records, sync, type, icon: Icon }) => <div className="source-management-card" key={name}><div className="source-management-card__icon"><Icon size={19} /></div><div className="source-management-card__main"><div className="source-management-card__name"><h3>{name}</h3><StatusBadge tone="success">Connected</StatusBadge></div><span className="mono">{detail}</span><div className="source-management-card__meta"><span><RefreshCw size={13} /> Last sync {sync}</span><span><FileCheck2 size={13} /> {records} records</span><span><Database size={13} /> {type}</span></div></div><div className="source-management-card__status"><div><span>Validation</span><strong><CheckCircle2 size={14} /> Passed</strong></div><button className="icon-button" onClick={() => toast(`${name} actions opened`)}><MoreHorizontal size={17} /></button></div></div>)}</div>
      <div className="upload-callout"><div><SectionLabel>Bring your next batch</SectionLabel><h2>Keep the evidence chain current.</h2><p>Upload settlement, bank, and ERP source files through the live intake below.</p></div><button className="button button--dark" onClick={() => document.getElementById("live-upload-intake")?.scrollIntoView({ behavior: "smooth", block: "start" })}><CloudUpload size={16} /> Open live uploader</button></div>
    </>
  );

  const renderAnalytics = () => (
    <>
      <PageHeading eyebrow="Workspace signals" title="Analytics" subtitle="Minimal operating metrics for match quality, queue health, and resolution time." actions={<button className="button button--ghost" onClick={() => toast("Date range selector opened") }><Clock3 size={15} /> Last 30 days <ChevronDown size={14} /></button>} />
      <div className="analytics-top"><div className="panel analytics-main"><div className="panel-heading"><div><SectionLabel>Match performance</SectionLabel><h2>Match rate over time</h2></div><div className="chart-label"><span className="legend-dot legend-dot--citron" /> Match rate <strong>94.96%</strong></div></div><MiniChart accent="citron" /></div><div className="panel analytics-stat"><SectionLabel>Queue health</SectionLabel><div className="analytics-stat__value">63</div><div className="analytics-stat__label">open exceptions</div><div className="analytics-stat__trend"><ArrowDownRight size={14} /> 12.4% vs prior period</div><div className="tiny-bars">{[34,52,43,67,50,72,64,84,71].map((h, i) => <span key={i} style={{ height: `${h}%` }} />)}</div></div></div>
      <div className="analytics-grid"><div className="panel"><div className="panel-heading"><div><SectionLabel>Category distribution</SectionLabel><h2>Exception rate</h2></div><PieChart size={17} className="muted-icon" /></div><div className="distribution-list">{[["Fee variance", "42%", "citron"],["Duplicate settlement", "25%", "terracotta"],["Timing delay", "18%", "blue"],["Partial refund", "9%", "sage"],["Unknown", "6%", "gray"]].map(([label, value, tone]) => <div key={label}><span><i className={`legend-dot legend-dot--${tone}`} />{label}</span><div className="distribution-track"><i className={`distribution-fill distribution-fill--${tone}`} style={{ width: value }} /></div><strong>{value}</strong></div>)}</div></div><div className="panel"><div className="panel-heading"><div><SectionLabel>Resolution efficiency</SectionLabel><h2>Time & approvals</h2></div><Zap size={17} className="accent-icon" /></div><div className="efficiency-grid"><div><span>Avg. resolution time</span><strong>2h 14m</strong><small><ArrowDownRight size={12} /> 18m faster</small></div><div><span>AI classification accuracy</span><strong>91.8%</strong><small><ArrowUpRight size={12} /> measured validation</small></div><div><span>Human approval rate</span><strong>98.4%</strong><small><CheckCircle2 size={12} /> bounded actions</small></div><div><span>Amount resolved</span><strong>₹4,18,200</strong><small><ArrowUpRight size={12} /> this period</small></div></div></div></div>
      <div className="panel analytics-compare"><div className="panel-heading"><div><SectionLabel>Signal history</SectionLabel><h2>AI classification accuracy</h2></div><button className="button button--text" onClick={() => go("validation")}>Open validation <ChevronRight size={15} /></button></div><MiniChart accent="sage" type="bars" /><div className="chart-axis chart-axis--full"><span>Week 1</span><span>Week 2</span><span>Week 3</span><span>Week 4</span></div></div>
    </>
  );

  const renderSettings = () => (
    <>
      <PageHeading eyebrow="Workspace configuration" title="Settings" subtitle="Configure merchant context, notification behavior, and review defaults." actions={<button className="button button--accent" onClick={() => toast.success("Settings saved") }><Check size={15} /> Save changes</button>} />
      <div className="settings-layout"><div className="settings-nav"><button className="settings-nav__item is-active"><BriefcaseBusiness size={16} /> Merchant profile</button><button className="settings-nav__item" onClick={() => toast("Notification settings opened")}><Bell size={16} /> Notifications</button><button className="settings-nav__item" onClick={() => toast("Member management opened")}><Users size={16} /> Team access</button><button className="settings-nav__item" onClick={() => toast("API settings opened")}><GitBranch size={16} /> Integrations</button></div><div className="settings-content"><div className="panel settings-panel"><div className="panel-heading"><div><SectionLabel>Merchant profile</SectionLabel><h2>Workspace identity</h2></div><StatusBadge tone="success">Active</StatusBadge></div><label className="field-label">Merchant name<input className="field-input" value="Owais Khan" readOnly /></label><label className="field-label">Workspace slug<input className="field-input mono" value="owais-khan-production" readOnly /></label><div className="field-row"><label className="field-label">Base currency<input className="field-input" value="INR · ₹" readOnly /></label><label className="field-label">Timezone<input className="field-input" value="Asia/Kolkata · GMT+5:30" readOnly /></label></div></div><div className="panel settings-panel"><div className="panel-heading"><div><SectionLabel>Review defaults</SectionLabel><h2>Human-in-the-loop controls</h2></div><SlidersHorizontal size={17} className="muted-icon" /></div><div className="toggle-row"><div><strong>Require approval for high-value actions</strong><span>Always on for amounts above ₹5,000.</span></div><div className="toggle is-on"><span /></div></div><div className="toggle-row"><div><strong>Notify on systemic patterns</strong><span>Alert Finance Ops when 3+ similar cases surface.</span></div><div className="toggle is-on"><span /></div></div><div className="toggle-row"><div><strong>Auto-refresh source health</strong><span>Check connected inputs every 15 minutes.</span></div><div className="toggle"><span /></div></div></div></div></div>
    </>
  );

  const titleByView: Record<ViewKey, string> = { overview: "Overview", reconciliation: "Reconciliation", exceptions: "Exceptions", ai: "AI Investigation", validation: "Validation", policy: "Policy Engine", audit: "Audit Trail", sources: "Data Sources", analytics: "Analytics", settings: "Settings" };
  const content = <>{ { overview: renderOverview, reconciliation: renderReconciliation, exceptions: renderExceptions, ai: renderAI, validation: renderValidation, policy: renderPolicy, audit: renderAudit, sources: renderSources, analytics: renderAnalytics, settings: renderSettings }[activeView]() }{activeView === "sources" && <UploadIntake />}</>;

  return (
    <div className={`app-shell theme-midnight neon-console ${sidebarCollapsed ? "sidebar-is-collapsed" : ""} ${mobileNavOpen ? "mobile-nav-is-open" : ""}`}>
      <aside className="side-rail">
        <div className="side-rail__top"><BrandLockup collapsed={sidebarCollapsed} /><button className="rail-toggle desktop-only" onClick={() => setSidebarCollapsed((value) => !value)} aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}>{sidebarCollapsed ? <PanelLeftOpen size={17} /> : <PanelLeftClose size={17} />}</button><button className="rail-toggle mobile-only" onClick={() => setMobileNavOpen(false)} aria-label="Close navigation"><X size={18} /></button></div>
        <div className="rail-section-label">Workspace</div>
        <nav className="side-nav">{navItems.map((item, index) => { const Icon = item.icon; return <button key={item.key} className={`side-nav__item ${activeView === item.key ? "is-active" : ""}`} onClick={() => go(item.key)} title={sidebarCollapsed ? item.label : undefined}><span className="side-nav__icon"><Icon size={17} strokeWidth={activeView === item.key ? 2.2 : 1.8} /></span><span className="side-nav__label">{item.label}</span>{item.key === "exceptions" && !sidebarCollapsed && <span className="side-nav__count">63</span>}{activeView === item.key && <span className="side-nav__marker" />}</button> })}</nav>
        <div className="rail-footer"><div className="system-status"><span className="status-badge__dot" /><span className="side-nav__label">All systems operational</span></div><div className="profile-mini"><div className="avatar">OK</div><div className="profile-mini__copy"><strong className="side-nav__label">Owais Khan</strong><span className="side-nav__label">Finance Ops</span></div><MoreHorizontal size={15} className="side-nav__label" /></div></div>
      </aside>
      <button type="button" className="mobile-scrim" aria-label="Close navigation" onClick={() => setMobileNavOpen(false)} />
      <main className="main-canvas">
        <header className="topbar"><div className="topbar__left"><button className="mobile-menu mobile-only" onClick={() => setMobileNavOpen(true)} aria-label="Open navigation"><Menu size={19} /></button><div className="topbar-product"><img src={LOGO_URL} alt="" /><strong>Ledger <span>Sherlock</span></strong></div><div className="breadcrumb"><span>Owais Khan</span><ChevronRight size={13} /><strong>{titleByView[activeView]}</strong></div></div><div className="topbar__right"><button className="global-search" onClick={() => setCommandOpen(true)} aria-label="Open quick find"><Search size={15} /><span>Quick find</span><kbd>⌘ K</kbd></button><div className="topbar-popover-wrap"><button className={`merchant-switcher ${merchantOpen ? "is-open" : ""}`} onClick={() => setMerchantOpen((value) => !value)}><span className="merchant-dot">OK</span><span>Owais Khan</span><ChevronDown size={14} /></button>{merchantOpen && <div className="popover merchant-popover"><SectionLabel>Current merchant</SectionLabel><strong>Owais Khan</strong><span>INR · Asia/Kolkata</span><button onClick={() => { setMerchantOpen(false); toast("Merchant switcher is ready for connected workspaces"); }}>Switch workspace <ChevronRight size={14} /></button></div>}</div><div className="topbar-popover-wrap"><button className={`icon-button notification-button ${notificationsOpen ? "is-active" : ""}`} onClick={() => setNotificationsOpen((value) => !value)} aria-label="Open notifications"><Bell size={17} /><span className="notification-dot" /></button>{notificationsOpen && <div className="popover notifications-popover"><div className="popover-heading"><strong>Notifications</strong><span>2 new</span></div><div className="notification-item"><span className="notification-item__icon notification-item__icon--amber"><CircleAlert size={15} /></span><div><strong>12 records require review</strong><span>Batch 08 · just now</span></div></div><div className="notification-item"><span className="notification-item__icon notification-item__icon--green"><CheckCircle2 size={15} /></span><div><strong>Reconciliation completed</strong><span>1,184 matches · 10:42</span></div></div></div>}</div><div className="avatar avatar--top">OK</div></div></header>
        <AnimatePresence mode="wait"><motion.div className="content-wrap" key={activeView} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}>{content}</motion.div></AnimatePresence>
        <footer className="app-footer"><span>Ledger Sherlock · Synthetic workspace data</span><span><span className="footer-dot" /> API-ready frontend · v0.9.4</span></footer>
      </main>

      <AnimatePresence>{commandOpen && <div className="modal-layer command-layer"><motion.div className="command-palette" role="dialog" aria-modal="true" aria-label="Quick find" initial={{ opacity: 0, y: 12, scale: 0.985 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 12, scale: 0.985 }} transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}><div className="command-search"><Search size={17} /><input ref={commandInputRef} value={commandQuery} onChange={(event) => setCommandQuery(event.target.value)} placeholder="Find a workspace view or action…" /><kbd>ESC</kbd><button type="button" className="icon-button icon-button--tiny" onClick={() => setCommandOpen(false)} aria-label="Close quick find"><X size={15} /></button></div><div className="command-section"><SectionLabel>Navigate</SectionLabel>{navItems.filter((item) => item.label.toLowerCase().includes(commandQuery.toLowerCase())).map((item) => { const Icon = item.icon; return <button className="command-item" key={item.key} onClick={() => { go(item.key); setCommandOpen(false); setCommandQuery(""); }}><span><Icon size={16} /> {item.label}</span><ChevronRight size={15} /></button>; })}</div><div className="command-section"><SectionLabel>Quick actions</SectionLabel><button className="command-item" onClick={() => { go("sources"); setCommandOpen(false); }}><span><Upload size={16} /> Open live uploader</span><kbd>U</kbd></button><button className="command-item" onClick={() => { setCommandOpen(false); startReconciliation(); }}><span><RefreshCw size={16} /> Run new reconciliation</span><kbd>R</kbd></button></div><div className="command-footer"><span><span className="footer-dot" /> Keyboard-friendly actions</span><span>Esc to close</span></div></motion.div></div>}</AnimatePresence>
      {selectedException && <div className="drawer-layer" onClick={() => setSelectedException(null)}><aside className="exception-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-header"><div><SectionLabel>Exception detail</SectionLabel><h2>{selectedException.id}</h2></div><button className="icon-button" onClick={() => setSelectedException(null)} aria-label="Close exception detail"><X size={17} /></button></div><div className="drawer-hero"><div><span>Amount</span><strong>{selectedException.amount}</strong></div><StatusBadge tone="warning">Requires review</StatusBadge></div><div className="drawer-section"><SectionLabel>Three-source comparison</SectionLabel><div className="source-compare"><div><span>Razorpay settlement</span><strong>₹48,500</strong><small>RP_92831 · 24 Aug</small></div><div className="source-compare__diff"><ArrowDownRight size={15} /><span>₹1,450 variance</span></div><div><span>Bank statement</span><strong>₹47,050</strong><small>BANK_82721 · 25 Aug</small></div><div className="source-compare__match"><CheckCircle2 size={14} /> ERP expected ₹48,500</div></div></div><div className="drawer-ai"><AIInvestigationCard onConfidence={() => setConfidenceOpen(true)} /></div><div className="drawer-control"><ApprovalCard /></div><div className="drawer-image"><img src={CASEFILE_URL} alt="Abstract case file investigation visual" /><div><SectionLabel>Evidence chain</SectionLabel><strong>Every mismatch leaves a trail.</strong></div></div></aside></div>}
      {confidenceOpen && <div className="modal-layer" onClick={() => setConfidenceOpen(false)}><div className="modal-card confidence-modal" onClick={(event) => event.stopPropagation()}><div className="modal-header"><div><SectionLabel>Confidence explanation</SectionLabel><h2>94% AI confidence</h2></div><button className="icon-button" onClick={() => setConfidenceOpen(false)}><X size={17} /></button></div><ConfidenceIndicator /><p className="modal-lead">Confidence describes the classifier's consistency for this unresolved exception. It is distinct from measured model accuracy.</p><div className="confidence-modal__columns"><div><SectionLabel>Based on</SectionLabel>{["Exception pattern","Historical labeled examples","Available transaction context","Classification consistency"].map((item) => <div className="basis-row" key={item}><Check size={14} />{item}</div>)}</div><div className="validation-callout"><SectionLabel>Validation-backed accuracy</SectionLabel><div><strong>Precision</strong><b>91.8%</b></div><div><strong>Recall</strong><b>88.4%</b></div><small>Measured on the labeled test set—not self-reported by AI.</small></div></div><button className="button button--dark button--full" onClick={() => setConfidenceOpen(false)}>Close explanation</button></div></div>}
    </div>
  );
}
