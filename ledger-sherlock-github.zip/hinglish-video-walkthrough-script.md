# Ledger Sherlock — Hinglish Walkthrough Narration

**Target runtime:** approximately 4 minutes.  
**Tone:** confident, simple, calm, and panel-friendly.  
**Important disclosure:** The Track 4 evaluation is based on Ledger Sherlock’s built-in, versioned **synthetic 60-case corpus**. It is a real deterministic evaluation of synthetic evidence, not a production merchant claim. Real uploaded files are securely stored after sign-in, but they are not yet automatically parsed into the reconciliation matcher.

## 1. Opening — Overview

**Show:** Overview page and the large Evidence Command Canvas.

“Hi panel. This is **Ledger Sherlock**, an explainable settlement controller for finance operations. Iska purpose sirf transactions ko match karna nahi hai. Iska purpose hai har reconciliation decision ke peeche ka evidence, rule, aur human control clearly dikhana.

Main screen par aap Evidence Command Canvas dekh rahe ho. Left side mein teen evidence sources hain: **Razorpay settlement export, bank credits, aur ERP ledger**. System in teenon sources ko compare karta hai.

Beech mein Evidence Trace hai. Ismein amount, reference, fee plus GST, aur ledger value ka comparison dikhta hai. Isliye judge ya finance operator ko black-box answer nahi milta; woh dekh sakta hai ki match kis rule se hua.

Right side mein do outcomes hain. Green card ka matlab records safely auto-cleared hue. Orange card ka matlab human review zaroori hai. Yahan important point ye hai ki AI ya system high-risk decision automatically pass nahi karta.

Ab main **Run controlled match** click karta hoon. Isse Reconciliation workspace open hota hai.”

## 2. Reconciliation — Measured proof loop

**Show:** Reconciliation page. Point to all three source cards and then the Track 4 proof loop.

“Reconciliation tab mein real product logic ka demo proof loop hai. Upar three inputs dikh rahe hain: settlement export, bank-credit window, aur ERP ledger.

Yahan **Run 60-case evaluation** button click karne par app fixed, versioned synthetic corpus chalata hai. Is dataset mein exact matches, fee plus GST cases, refunds, timing delays, missing credits, duplicates, aur ambiguous cases included hain. Yeh cherry-picked transaction list nahi hai.

Run ke time app evidence inputs seal karta hai, deterministic finance rules apply karta hai, aur audit result prepare karta hai. Run complete hone ke baad measured scorecard dikhta hai: total cases, source records, deterministic match rate, decision accuracy, false-positive auto closes, aur elapsed time.

Demo corpus ke observed result mein **60 cases aur 174 source records** evaluate hue. **52 safely auto-close hue, 4 timing cases monitor hue, aur 4 intentionally unresolved rahe**. Deterministic auto-close rate 86.7 percent tha, ground-truth decision accuracy 100 percent thi, aur unsafe false-positive auto-resolution zero tha. Yeh numbers specifically synthetic corpus ke hain—production merchant numbers nahi.

Neeche Honest Residual Queue hai. Main kisi unresolved case ko click karta hoon. Right panel mein us case ka escalation packet ready hota hai. **Download escalation packet** click karne se JSON file milti hai, jisme evidence, reason, recommended owner, aur next step hota hai. Iska use finance team ko context ke saath escalation dene ke liye hai.”

## 3. Bounded AI Investigation

**Show:** Reconciliation page’s “Run bounded AI review” area, then click AI Investigation in the left navigation.

“Ab **Run bounded AI review** click karne se AI sirf residual cases ko classify karta hai—poore finance dataset ko AI ke paas nahi bheja jata. AI fixed taxonomy ke andar response deta hai, source evidence cite karta hai, aur human approval ke bina financial action nahi le sakta.

Left navigation ke **AI Investigation** tab mein operator ko classification, confidence, explanation, aur suggested next step milta hai. Confidence ka matlab measured accuracy nahi hai; yeh current case ke evidence ke saath classifier consistency ka signal hai.

Confidence card par click karne se aap basis dekh sakte ho—pattern, historical labels, available transaction context, aur consistency. High-value action ke liye **Human approval required** card clear boundary dikhata hai. Approve ya reject click karne par decision audit workflow mein record hota hai; automatic money movement nahi hota.”

## 4. Exceptions queue

**Show:** Exceptions tab, filter pills, search, and one clicked row with its detail drawer.

“Ab **Exceptions** tab open karta hoon. Yahan woh records aate hain jinhe confidently auto-reconcile nahi kiya gaya. Operator category filter use kar sakta hai—for example fee variance, duplicate settlement, partial refund, ya timing delay. Search box se transaction ID ya issue directly find ho jata hai.

Kisi row par click karne se detail drawer khulta hai. Is drawer mein Razorpay settlement, bank statement, aur ERP expected value ka three-source comparison hota hai. Saath mein AI explanation aur policy control dikhte hain. Is view ka purpose sirf alert dena nahi—human ko decision lene ke liye complete evidence dena hai.

Interface ka open-exception count sample workspace context show karta hai. Verified Track 4 corpus ke actual residual count ke liye panel ko Reconciliation page ka measured 60-case result refer karna chahiye.”

## 5. Validation and Policy Engine

**Show:** Validation tab, then Policy Engine tab.

“**Validation** tab model quality ko separate karta hai. Yahan predicted versus actual classification aur precision-recall style scorecards dikhte hain. Yeh reminder hai ki AI confidence aur tested performance same thing nahi hote. Current build ka verified demo measurement Reconciliation ke 60-case proof loop mein visible hai.

Ab **Policy Engine** mein aate hain. Yahan system boundaries define hoti hain. Low-value mismatch auto-resolve ho sakta hai. Medium-value mismatch ke liye draft query banti hai, lekin human send se pehle approve karega. High-value mismatch ke liye human review compulsory hai.

Isliye Ledger Sherlock ka core claim automation nahi, **safe automation** hai.”

## 6. Audit Trail and Data Sources

**Show:** Audit Trail then Data Sources.

“**Audit Trail** tab mein har action ka chronological record hai—record ID, rule triggered, AI classification, human approval, user, aur final status. Isse finance team answer de sakti hai: what happened, why happened, aur kisne approve kiya.

**Data Sources** tab mein settlement, bank, aur ERP files ka status dikhta hai. **Upload new dataset** click karne par live file intake open hota hai. User CSV, bank statement, aur allowed files choose ya drag-and-drop kar sakta hai. File policy size aur unsafe file types validate karti hai.

Yahan ek honest boundary hai: file chooser screen sign-in se pehle visible reh sakti hai, lekin actual secure storage ke liye user authentication required hai. Files managed storage mein safely save hote hain aur batch metadata database mein persist hota hai. Abhi uploaded CSV directly deterministic reconciliation engine ko feed nahi karta—yeh next implementation step hai.”

## 7. Analytics, Settings, and Closing

**Show:** Analytics, Settings, return to Overview.

“**Analytics** tab match quality, open queue health, aur exception categories ko operational view mein summarize karta hai. **Settings** mein merchant context, base currency, timezone, notification defaults, aur human-in-the-loop controls manage hote hain.

To summarize: Ledger Sherlock settlement evidence ko compare karta hai, deterministic rules se safe cases close karta hai, risky cases ko human queue mein bhejta hai, AI ko bounded investigation ke liye use karta hai, policy gate enforce karta hai, aur complete audit trail maintain karta hai.

Yahi is project ka difference hai: it is not an AI chatbot for finance. It is an **explainable, controlled finance operations system**.”
