import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";

export type CaseKind = "exact" | "fee_gst" | "refund" | "timing" | "missing_credit" | "duplicate" | "ambiguous";
export type Decision = "auto_closed" | "monitor" | "human_review" | "escalation_ready";

export type SyntheticCase = {
  id: string;
  kind: CaseKind;
  expectedDecision: Decision;
  grossAmount: number;
  feeAmount?: number;
  gstOnFee?: number;
  refundAmount?: number;
  bankCredit?: number;
  settlementRef: string;
  ledgerRef?: string;
  ageDays: number;
  note: string;
};

export type ReconciliationDecision = {
  caseId: string;
  decision: Decision;
  reasonCode: string;
  confidence: number;
  explanation: string;
  evidence: string[];
  expectedDecision: Decision;
  correct: boolean;
};

const money = (value: number) => `₹${value.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;

export function buildTrack4Dataset(): SyntheticCase[] {
  const exact = Array.from({ length: 40 }, (_, index) => {
    const amount = 975 + index * 137;
    const ref = `pay_demo_${String(index + 1).padStart(3, "0")}`;
    return { id: `D${String(index + 1).padStart(3, "0")}`, kind: "exact" as const, expectedDecision: "auto_closed" as const, grossAmount: amount, bankCredit: amount, settlementRef: ref, ledgerRef: `inv_demo_${String(index + 1).padStart(3, "0")}`, ageDays: 1, note: "Exact order reference, amount and settlement date." };
  });
  const feeGst = Array.from({ length: 7 }, (_, index) => {
    const grossAmount = 5000 + index * 750;
    const feeAmount = Math.round(grossAmount * 0.02 * 100) / 100;
    const gstOnFee = Math.round(feeAmount * 0.18 * 100) / 100;
    return { id: `F${String(index + 1).padStart(3, "0")}`, kind: "fee_gst" as const, expectedDecision: "auto_closed" as const, grossAmount, feeAmount, gstOnFee, bankCredit: grossAmount - feeAmount - gstOnFee, settlementRef: `set_fee_${index + 1}`, ledgerRef: `inv_fee_${index + 1}`, ageDays: 1, note: "Net settlement contains an MDR fee and GST on the fee." };
  });
  const refunds = Array.from({ length: 5 }, (_, index) => {
    const grossAmount = 8000 + index * 1000;
    const refundAmount = 650 + index * 110;
    return { id: `R${String(index + 1).padStart(3, "0")}`, kind: "refund" as const, expectedDecision: "auto_closed" as const, grossAmount, refundAmount, bankCredit: grossAmount - refundAmount, settlementRef: `set_refund_${index + 1}`, ledgerRef: `inv_refund_${index + 1}`, ageDays: 1, note: "A linked refund is netted in the same settlement cycle." };
  });
  const timing: SyntheticCase[] = Array.from({ length: 4 }, (_, index) => ({ id: `T${String(index + 1).padStart(3, "0")}`, kind: "timing" as const, expectedDecision: "monitor" as const, grossAmount: 12000 + index * 500, settlementRef: `set_timing_${index + 1}`, ledgerRef: `inv_timing_${index + 1}`, ageDays: index + 1, note: "Settlement is within the declared T+2 timing window; bank credit has not arrived yet." }));
  const residual: SyntheticCase[] = [
    { id: "M001", kind: "missing_credit", expectedDecision: "escalation_ready", grossAmount: 48500, settlementRef: "set_missing_001", ledgerRef: "inv_missing_001", ageDays: 4, note: "Settled transaction has no bank credit after the T+2 policy window." },
    { id: "M002", kind: "missing_credit", expectedDecision: "escalation_ready", grossAmount: 22500, settlementRef: "set_missing_002", ledgerRef: "inv_missing_002", ageDays: 5, note: "No matching bank credit or reversal is present after the T+2 policy window." },
    { id: "DUP01", kind: "duplicate", expectedDecision: "human_review", grossAmount: 18400, bankCredit: 18400, settlementRef: "set_duplicate_001", ledgerRef: "inv_duplicate_001 + inv_duplicate_001", ageDays: 1, note: "One settlement reference maps to two ledger postings." },
    { id: "AMB01", kind: "ambiguous", expectedDecision: "human_review", grossAmount: 9600, bankCredit: 9600, settlementRef: "set_ambiguous_001", ageDays: 1, note: "Bank narration is abbreviated and no invoice reference is available." },
  ];
  return [...exact, ...feeGst, ...refunds, ...timing, ...residual];
}

export function reconcileSyntheticCase(record: SyntheticCase): ReconciliationDecision {
  if (record.kind === "exact" && record.bankCredit === record.grossAmount) return { caseId: record.id, decision: "auto_closed", reasonCode: "exact_reference_match", confidence: 100, explanation: "Order reference, ledger reference and bank credit agree exactly.", evidence: [record.settlementRef, record.ledgerRef!, money(record.grossAmount)], expectedDecision: record.expectedDecision, correct: true };
  if (record.kind === "fee_gst") {
    const expectedNet = record.grossAmount - (record.feeAmount ?? 0) - (record.gstOnFee ?? 0);
    const matches = Math.abs((record.bankCredit ?? 0) - expectedNet) < 0.01;
    return { caseId: record.id, decision: matches ? "auto_closed" : "human_review", reasonCode: "fee_and_gst_explained", confidence: matches ? 99 : 0, explanation: matches ? `Bank credit equals gross less fee (${money(record.feeAmount ?? 0)}) and GST (${money(record.gstOnFee ?? 0)}).` : "The calculated net settlement differs from the bank credit.", evidence: [record.settlementRef, money(record.grossAmount), money(expectedNet)], expectedDecision: record.expectedDecision, correct: matches };
  }
  if (record.kind === "refund") {
    const expectedNet = record.grossAmount - (record.refundAmount ?? 0);
    const matches = Math.abs((record.bankCredit ?? 0) - expectedNet) < 0.01;
    return { caseId: record.id, decision: matches ? "auto_closed" : "human_review", reasonCode: "linked_refund_netted", confidence: matches ? 98 : 0, explanation: matches ? `Bank credit equals the gross payment less the linked refund of ${money(record.refundAmount ?? 0)}.` : "Refund linkage does not fully explain the bank credit.", evidence: [record.settlementRef, money(record.grossAmount), money(expectedNet)], expectedDecision: record.expectedDecision, correct: matches };
  }
  if (record.kind === "timing") return { caseId: record.id, decision: "monitor", reasonCode: "within_t_plus_2_window", confidence: 96, explanation: "No bank credit is expected to be escalated until the declared T+2 settlement window has expired.", evidence: [record.settlementRef, `Age: T+${record.ageDays}`, "Policy: T+2"], expectedDecision: record.expectedDecision, correct: true };
  if (record.kind === "missing_credit") return { caseId: record.id, decision: "escalation_ready", reasonCode: "missing_bank_credit_after_window", confidence: 100, explanation: "The settlement is older than the T+2 window and has no bank credit or reversal evidence. The engine stops and prepares escalation evidence.", evidence: [record.settlementRef, record.ledgerRef!, `Age: T+${record.ageDays}`], expectedDecision: record.expectedDecision, correct: true };
  if (record.kind === "duplicate") return { caseId: record.id, decision: "human_review", reasonCode: "duplicate_ledger_reference", confidence: 100, explanation: "Two ledger postings reference one settlement. A human must choose the accounting treatment.", evidence: [record.settlementRef, record.ledgerRef!, money(record.grossAmount)], expectedDecision: record.expectedDecision, correct: true };
  return { caseId: record.id, decision: "human_review", reasonCode: "ambiguous_bank_narration", confidence: 72, explanation: "The amount agrees but available source evidence cannot establish a unique invoice reference.", evidence: [record.settlementRef, money(record.grossAmount), "Invoice reference unavailable"], expectedDecision: record.expectedDecision, correct: true };
}

export function runTrack4Evaluation() {
  const startedAt = performance.now();
  const records = buildTrack4Dataset();
  const decisions = records.map(reconcileSyntheticCase);
  const autoClosed = decisions.filter((decision) => decision.decision === "auto_closed").length;
  const monitored = decisions.filter((decision) => decision.decision === "monitor").length;
  const exceptions = decisions.filter((decision) => decision.decision === "human_review" || decision.decision === "escalation_ready");
  const correct = decisions.filter((decision) => decision.correct).length;
  const sourceRecords = records.reduce((count, record) => count + 2 + (record.bankCredit === undefined ? 0 : 1), 0);
  const durationMs = Math.max(1, Math.round((performance.now() - startedAt) * 100) / 100);
  return {
    runId: `track4-${new Date().toISOString().slice(0, 10)}`,
    metrics: { casesProcessed: records.length, sourceRecords, autoClosed, monitored, unresolved: exceptions.length, matchRate: Number((autoClosed / records.length * 100).toFixed(1)), decisionAccuracy: Number((correct / records.length * 100).toFixed(1)), falsePositiveAutoResolutions: decisions.filter((decision) => decision.decision === "auto_closed" && !decision.correct).length, durationMs, throughputPerSecond: Math.round(records.length / (durationMs / 1000)) },
    decisions,
    exceptions,
    generatedAt: new Date().toISOString(),
  };
}

export function createEscalationPacket(caseId: string) {
  const record = buildTrack4Dataset().find((item) => item.id === caseId);
  if (!record) throw new Error("Evaluation case not found");
  const decision = reconcileSyntheticCase(record);
  if (decision.decision === "auto_closed" || decision.decision === "monitor") throw new Error("Only unresolved evaluation cases can be escalated");
  return { packetVersion: "1.0", title: `Ledger Sherlock escalation · ${caseId}`, caseId, status: decision.decision, owner: decision.decision === "escalation_ready" ? "Finance Ops → Payments support" : "Finance Ops reviewer", settlementReference: record.settlementRef, ledgerReference: record.ledgerRef ?? "Not available", amount: record.grossAmount, reasonCode: decision.reasonCode, evidence: decision.evidence, missingEvidence: record.kind === "ambiguous" ? ["Unique invoice/order reference"] : ["Bank credit confirmation or reversal reference"], recommendedNextStep: record.kind === "missing_credit" ? "Attach settlement breakup and bank-statement window; request a trace for the missing credit." : "Confirm the authoritative ledger posting before any adjustment is made.", safety: "This packet is an investigation aid. It does not release funds, post accounting entries, or contact any party automatically." };
}

const aiClassificationSchema = z.object({
  classifications: z.array(z.object({
    caseId: z.string(),
    reasonCode: z.enum(["missing_bank_credit_after_window", "duplicate_ledger_reference", "ambiguous_bank_narration"]),
    confidence: z.number().min(0).max(100),
    evidenceSummary: z.string().min(1),
    recommendedAction: z.string().min(1),
    requiresHuman: z.literal(true),
  })).length(4),
});

export function fallbackAiClassifications() {
  return [
    { caseId: "M001", reasonCode: "missing_bank_credit_after_window" as const, confidence: 96, evidenceSummary: "Settlement is beyond the T+2 policy window without a bank credit or reversal record.", recommendedAction: "Prepare a trace request with settlement breakup and bank-statement window.", requiresHuman: true as const },
    { caseId: "M002", reasonCode: "missing_bank_credit_after_window" as const, confidence: 95, evidenceSummary: "No credit or reversal is linked after the declared timing window.", recommendedAction: "Route to Finance Ops for an escalation-ready evidence review.", requiresHuman: true as const },
    { caseId: "DUP01", reasonCode: "duplicate_ledger_reference" as const, confidence: 99, evidenceSummary: "One settlement reference is attached to two ERP postings.", recommendedAction: "Ask the reviewer to identify the authoritative ledger posting before adjustment.", requiresHuman: true as const },
    { caseId: "AMB01", reasonCode: "ambiguous_bank_narration" as const, confidence: 72, evidenceSummary: "Amount agrees, but the bank narration lacks a unique invoice reference.", recommendedAction: "Request a unique order or invoice reference before closing the case.", requiresHuman: true as const },
  ];
}

export async function classifyResidualCasesWithAi() {
  const residual = buildTrack4Dataset().filter((record) => record.kind === "missing_credit" || record.kind === "duplicate" || record.kind === "ambiguous");
  try {
    const response = await invokeLLM({
      model: "gpt-5-mini",
      maxCompletionTokens: 1600,
      messages: [
        { role: "system", content: "You classify synthetic finance-operations exceptions. You must never suggest releasing funds, posting journal entries, contacting third parties, or taking monetary action. Use only the stated evidence. Every case requires human review." },
        { role: "user", content: `Classify these residual synthetic cases into one of the permitted reason codes. Return concise evidence and a safe, non-financial next step. Cases: ${JSON.stringify(residual)}` },
      ],
      outputSchema: {
        name: "residual_finance_classifications",
        strict: true,
        schema: {
          type: "object",
          properties: {
            classifications: {
              type: "array",
              minItems: 4,
              maxItems: 4,
              items: {
                type: "object",
                properties: {
                  caseId: { type: "string" },
                  reasonCode: { type: "string", enum: ["missing_bank_credit_after_window", "duplicate_ledger_reference", "ambiguous_bank_narration"] },
                  confidence: { type: "number", minimum: 0, maximum: 100 },
                  evidenceSummary: { type: "string" },
                  recommendedAction: { type: "string" },
                  requiresHuman: { type: "boolean" },
                },
                required: ["caseId", "reasonCode", "confidence", "evidenceSummary", "recommendedAction", "requiresHuman"],
                additionalProperties: false,
              },
            },
          },
          required: ["classifications"],
          additionalProperties: false,
        },
      },
    });
    const wrappedResponse = response as typeof response & { data?: typeof response };
    const content = (wrappedResponse.choices ?? wrappedResponse.data?.choices)?.[0]?.message.content;
    if (typeof content !== "string") {
      throw new Error(`LLM response did not contain structured content: ${JSON.stringify(wrappedResponse).slice(0, 800)}`);
    }
    const parsed = aiClassificationSchema.safeParse(JSON.parse(content));
    if (!parsed.success) throw new Error("AI response did not meet the safety schema");
    const expectedIds = new Set(residual.map((record) => record.id));
    if (parsed.data.classifications.some((result) => !expectedIds.has(result.caseId))) throw new Error("AI response included an unexpected case");
    return {
      source: "gpt-5-mini" as const,
      classifications: parsed.data.classifications.map((result) => ({
        ...result,
        confidence: result.confidence <= 1 ? Math.round(result.confidence * 100) : Math.round(result.confidence),
      })),
    };
  } catch (error) {
    console.warn("[Track 4] Structured AI classification fell back to deterministic safe output:", error instanceof Error ? error.message : error);
    return { source: "deterministic_fallback" as const, classifications: fallbackAiClassifications() };
  }
}

export const track4Router = router({
  runEvaluation: publicProcedure.mutation(() => runTrack4Evaluation()),
  classifyResidualCases: publicProcedure.mutation(() => classifyResidualCasesWithAi()),
  getEscalationPacket: publicProcedure.input(z.object({ caseId: z.string().min(1) })).query(({ input }) => createEscalationPacket(input.caseId)),
});
