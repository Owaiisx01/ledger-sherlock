import { z } from "zod";
import * as db from "../db";
import { storagePut } from "../storage";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";

const MAX_FILE_BYTES = 10 * 1024 * 1024;
const MAX_BATCH_BYTES = 30 * 1024 * 1024;
const MAX_FILES_PER_BATCH = 3;
const BLOCKED_EXTENSIONS = new Set(["apk", "bat", "cmd", "com", "dll", "dmg", "exe", "jar", "msi", "ps1", "sh", "vbs"]);

export type UploadCategory = "tabular" | "document" | "image" | "media" | "archive" | "other";

export function sanitizeUploadName(value: string) {
  return value.replace(/[^a-zA-Z0-9._-]/g, "_").replace(/^[_\.]+/, "").slice(0, 180) || "upload";
}

export function categorizeUpload(name: string, mimeType: string): UploadCategory {
  const extension = name.split(".").pop()?.toLowerCase() ?? "";
  if (["csv", "tsv", "xls", "xlsx", "json", "xml"].includes(extension)) return "tabular";
  if (mimeType.startsWith("image/")) return "image";
  if (mimeType.startsWith("audio/") || mimeType.startsWith("video/")) return "media";
  if (["zip", "rar", "7z", "tar", "gz"].includes(extension)) return "archive";
  if (["pdf", "doc", "docx", "ppt", "pptx", "txt", "rtf", "md"].includes(extension)) return "document";
  return "other";
}

export function validateUploadPolicy(name: string, byteSize: number) {
  const extension = name.split(".").pop()?.toLowerCase() ?? "";
  if (BLOCKED_EXTENSIONS.has(extension)) return `.${extension} files cannot be uploaded for security reasons`;
  if (!Number.isFinite(byteSize) || byteSize < 1) return "Each file must contain data";
  if (byteSize > MAX_FILE_BYTES) return "Each file must be 10 MB or smaller";
  return null;
}

export function validateBatchPolicy(files: Array<{ name: string; byteSize: number }>) {
  if (files.length > MAX_FILES_PER_BATCH) return "A reconciliation batch can contain up to 3 files";
  const invalidFile = files.map((file) => validateUploadPolicy(file.name, file.byteSize)).find(Boolean);
  if (invalidFile) return invalidFile;
  if (files.reduce((total, file) => total + file.byteSize, 0) > MAX_BATCH_BYTES) return "A reconciliation batch can contain up to 30 MB of files";
  return null;
}

const fileInput = z.object({
  name: z.string().min(1).max(512),
  mimeType: z.string().max(255).default("application/octet-stream"),
  byteSize: z.number().int().positive().max(MAX_FILE_BYTES),
  contentBase64: z.string().min(1),
});

export const uploadsRouter = router({
  listBatches: publicProcedure.query(({ ctx }) => ctx.user ? db.listRecentReconciliationBatches(ctx.user.id) : []),
  listFiles: protectedProcedure.input(z.object({ batchId: z.number().int().positive() })).query(({ ctx, input }) => db.listReconciliationFiles(input.batchId, ctx.user.id)),
  createBatch: protectedProcedure.input(z.object({ files: z.array(fileInput).min(1).max(MAX_FILES_PER_BATCH) })).mutation(async ({ ctx, input }) => {
    const policyError = validateBatchPolicy(input.files);
    if (policyError) throw new Error(policyError);
    const batchId = await db.createReconciliationBatch(ctx.user.id, input.files.length);
    const stored = [] as Array<{ name: string; url: string; category: UploadCategory }>;
    for (const file of input.files) {
      const fileName = sanitizeUploadName(file.name);
      const bytes = Buffer.from(file.contentBase64, "base64");
      if (bytes.byteLength !== file.byteSize) throw new Error(`${file.name} could not be verified after upload encoding`);
      const storedFile = await storagePut(`users/${ctx.user.id}/reconciliation/${batchId}/${fileName}`, bytes, file.mimeType || "application/octet-stream");
      const category = categorizeUpload(fileName, file.mimeType);
      await db.createReconciliationFile({ batchId, userId: ctx.user.id, fileName, fileKey: storedFile.key, storageUrl: storedFile.url, mimeType: file.mimeType || "application/octet-stream", byteSize: file.byteSize, category });
      stored.push({ name: fileName, url: storedFile.url, category });
    }
    return { batchId, status: "received" as const, files: stored };
  }),
});
