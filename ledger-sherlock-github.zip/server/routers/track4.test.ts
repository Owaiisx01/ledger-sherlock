import { describe, expect, it } from "vitest";
import { buildTrack4Dataset, createEscalationPacket, fallbackAiClassifications, reconcileSyntheticCase, runTrack4Evaluation } from "./track4";

describe("Track 4 deterministic reconciliation evaluation", () => {
  it("contains a ground-truth corpus with at least sixty cases and representative finance operations", () => {
    const records = buildTrack4Dataset();
    expect(records).toHaveLength(60);
    expect(records.filter((record) => record.kind === "exact")).toHaveLength(40);
    expect(records.filter((record) => record.kind === "missing_credit")).toHaveLength(2);
    expect(records.some((record) => record.kind === "fee_gst")).toBe(true);
  });

  it("calculates a finance-aware fee and GST settlement explanation", () => {
    const feeCase = buildTrack4Dataset().find((record) => record.kind === "fee_gst")!;
    const decision = reconcileSyntheticCase(feeCase);
    expect(decision).toMatchObject({ decision: "auto_closed", reasonCode: "fee_and_gst_explained", correct: true });
  });

  it("reports transparent metrics and does not auto-close residual exceptions", () => {
    const result = runTrack4Evaluation();
    expect(result.metrics).toMatchObject({ casesProcessed: 60, autoClosed: 52, monitored: 4, unresolved: 4, decisionAccuracy: 100, falsePositiveAutoResolutions: 0 });
    expect(result.exceptions.map((exception) => exception.caseId)).toEqual(["M001", "M002", "DUP01", "AMB01"]);
  });

  it("creates an escalation packet only for unresolved cases", () => {
    expect(createEscalationPacket("M001")).toMatchObject({ caseId: "M001", status: "escalation_ready", reasonCode: "missing_bank_credit_after_window" });
    expect(() => createEscalationPacket("D001")).toThrow("Only unresolved");
  });

  it("keeps AI fallback output bounded to residual cases and mandatory human review", () => {
    const classifications = fallbackAiClassifications();
    expect(classifications).toHaveLength(4);
    expect(classifications.every((classification) => classification.requiresHuman)).toBe(true);
    expect(classifications.map((classification) => classification.caseId)).toEqual(["M001", "M002", "DUP01", "AMB01"]);
  });
});
