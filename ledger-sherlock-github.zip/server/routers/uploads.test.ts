import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  createReconciliationBatch: vi.fn(),
  createReconciliationFile: vi.fn(),
  storagePut: vi.fn(),
}));

vi.mock("../db", () => ({
  createReconciliationBatch: mocks.createReconciliationBatch,
  createReconciliationFile: mocks.createReconciliationFile,
}));

vi.mock("../storage", () => ({ storagePut: mocks.storagePut }));

import { categorizeUpload, sanitizeUploadName, uploadsRouter, validateBatchPolicy, validateUploadPolicy } from "./uploads";

describe("upload helpers", () => {
  beforeEach(() => {
    mocks.createReconciliationBatch.mockReset();
    mocks.createReconciliationFile.mockReset();
    mocks.storagePut.mockReset();
  });
  it("sanitizes file names before building storage keys", () => {
    expect(sanitizeUploadName("../../Bank statement (Aug).csv")).toBe("Bank_statement__Aug_.csv");
  });

  it("categorizes common reconciliation source files", () => {
    expect(categorizeUpload("settlement.csv", "text/csv")).toBe("tabular");
    expect(categorizeUpload("invoice.pdf", "application/pdf")).toBe("document");
    expect(categorizeUpload("proof.png", "image/png")).toBe("image");
  });

  it("rejects executable, empty, and oversized files before storage", () => {
    expect(validateUploadPolicy("ledger.exe", 20)).toContain("cannot be uploaded");
    expect(validateUploadPolicy("empty.csv", 0)).toBe("Each file must contain data");
    expect(validateUploadPolicy("large.csv", 10 * 1024 * 1024 + 1)).toBe("Each file must be 10 MB or smaller");
  });

  it("limits a batch to three files and thirty megabytes", () => {
    expect(validateBatchPolicy([{ name: "a.csv", byteSize: 1 }, { name: "b.csv", byteSize: 1 }, { name: "c.csv", byteSize: 1 }, { name: "d.csv", byteSize: 1 }])).toContain("up to 3 files");
    expect(validateBatchPolicy([{ name: "a.csv", byteSize: 10 * 1024 * 1024 }, { name: "b.csv", byteSize: 10 * 1024 * 1024 }, { name: "c.csv", byteSize: 10 * 1024 * 1024 + 1 }])).toContain("10 MB");
  });

  it("stores a valid batch and persists file metadata after backend validation", async () => {
    mocks.createReconciliationBatch.mockResolvedValue(73);
    mocks.storagePut.mockResolvedValue({ key: "users/7/reconciliation/73/bank.csv_abcd1234", url: "/manus-storage/users/7/reconciliation/73/bank.csv_abcd1234" });
    mocks.createReconciliationFile.mockResolvedValue(undefined);
    const caller = uploadsRouter.createCaller({ user: { id: 7 } } as any);
    const result = await caller.createBatch({ files: [{ name: "bank.csv", mimeType: "text/csv", byteSize: 5, contentBase64: Buffer.from("hello").toString("base64") }] });

    expect(mocks.createReconciliationBatch).toHaveBeenCalledWith(7, 1);
    expect(mocks.storagePut).toHaveBeenCalledWith("users/7/reconciliation/73/bank.csv", expect.any(Buffer), "text/csv");
    expect(mocks.createReconciliationFile).toHaveBeenCalledWith(expect.objectContaining({ batchId: 73, userId: 7, fileName: "bank.csv", category: "tabular" }));
    expect(result).toEqual(expect.objectContaining({ batchId: 73, status: "received", files: [expect.objectContaining({ name: "bank.csv", category: "tabular" })] }));
  });
});
