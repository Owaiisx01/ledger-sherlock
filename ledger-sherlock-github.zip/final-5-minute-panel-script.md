# Ledger Sherlock — 5-Minute Panel Walkthrough Script

## Recording guidance

Speak like you are explaining your own project to a panel, not reading an advertisement. Keep the screen visible while you speak. Pause naturally at every **[pause]** cue. The bracketed screen directions are not spoken.

## Script

**[Overview screen]**

Hello everyone. I am presenting Ledger Sherlock, an explainable finance reconciliation controller for settlement operations.

Let me start with the problem. A business receives a settlement report, bank credits, and ERP records. These sources often do not match perfectly. There may be fees, refunds, timing differences, missing credits, or duplicates.

Finance teams spend a lot of time checking these records manually. But the bigger problem is trust. When a system says a transaction is matched, the team must know why and what evidence supports it. [pause]

That is what Ledger Sherlock is built to solve.

**[Move around the Overview screen]**

This is the main control view. On the left are settlement, bank, and ERP evidence. In the center is the evidence trace. On the right are controlled outcomes—what can be cleared and what needs a human.

It shows the decision path behind the match number.

**[Open Reconciliation]**

Now I move to Reconciliation. This is the core workflow.

First, incoming evidence is checked. Then finance-aware rules compare references, amounts, fees, GST, refunds, timing, missing credits, duplicates, and ambiguous cases.

The order is important. Clear rules run first. We do not send every transaction to AI. If the evidence is strong, the system can resolve the case with an explanation. If the evidence is not strong enough, it stays open for review. [pause]

**[Show the Track 4 evaluation]**

For this demonstration, I can run a controlled sixty-case evaluation. This is a versioned synthetic test corpus, not live merchant data. It includes exact matches, fee differences, refunds, timing issues, missing credits, duplicates, and ambiguous records.

The result is measured against known ground truth. We can see automatic resolutions, unresolved cases, accuracy, and false-positive auto-resolutions. A finance system should be checked for correct decisions, not just confident answers.

**[Open Exceptions]**

This is the Exceptions view. It is the smaller residual queue left after safe rules handle the clear cases.

For each exception, the operator sees the reason, evidence, confidence, and next action. The team can focus on the cases that need attention.

**[Open AI Investigation]**

This is where AI is used, but in a controlled way.

A general AI tool can read a transaction and give an answer. But it may not know company policy, may not have complete evidence, and may answer without an approval process. In finance, a confident wrong answer can be worse than an unfinished case.

Ledger Sherlock uses AI only after deterministic checks and only for unresolved cases. It receives structured evidence and returns a classification, confidence, reasoning, and suggested owner. It cannot silently close the transaction. A human still gives the final approval. [pause]

That is the main difference in this product. AI is not being added as decoration. It is placed inside an evidence, policy, and human-control workflow.

**[Show escalation packet]**

For a serious exception, the system can create an escalation packet. It contains the case ID, source evidence, decision history, and recommended owner. This creates an investigation package another team can act on.

**[Open Validation and Policy Engine]**

Validation checks the input structure before matching. Policy Engine defines the boundaries: small differences may be automatic, medium differences may require review, and high-risk cases go to a human.

This is important because good finance automation must know when to stop.

**[Open Audit Trail]**

Audit Trail records what happened: which evidence arrived, which rule ran, what decision was made, and who approved the action. This gives the team accountability.

**[Open Data Sources]**

Data Sources is where settlement, bank, and ERP files are prepared. The upload and storage flow is protected by authentication. In the current build, secure upload and metadata storage are real, but uploaded CSV files are not yet automatically parsed into the matching engine. The Track 4 proof run uses a separate synthetic corpus. I am stating this clearly because a trustworthy product should not present a demo result as live production ingestion.

**[Closing screen]**

So, in one sentence, Ledger Sherlock receives financial evidence, validates it, applies explainable rules, sends only uncertain cases to bounded AI review, keeps a human approval gate, and creates an audit-ready trail.

Many tools can add AI to a finance screen. Ledger Sherlock is different because it focuses on evidence, safe decisions, and human control. It makes uncertainty visible and manageable.

That is Ledger Sherlock’s value for the AI Finance Controller track: faster reconciliation, clearer explanations, safer automation, and better control.

Thank you.
