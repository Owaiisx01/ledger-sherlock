CREATE TABLE `reconciliationBatches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`status` enum('received','processing','ready','failed') NOT NULL DEFAULT 'received',
	`fileCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reconciliationBatches_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reconciliationFiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`batchId` int NOT NULL,
	`userId` int NOT NULL,
	`fileName` varchar(512) NOT NULL,
	`fileKey` varchar(1024) NOT NULL,
	`storageUrl` varchar(2048) NOT NULL,
	`mimeType` varchar(255) NOT NULL,
	`byteSize` int NOT NULL,
	`category` enum('tabular','document','image','media','archive','other') NOT NULL DEFAULT 'other',
	`fileStatus` enum('stored','invalid','failed') NOT NULL DEFAULT 'stored',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reconciliationFiles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
