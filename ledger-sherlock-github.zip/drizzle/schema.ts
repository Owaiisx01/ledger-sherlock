import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const reconciliationBatches = mysqlTable("reconciliationBatches", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["received", "processing", "ready", "failed"]).default("received").notNull(),
  fileCount: int("fileCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const reconciliationFiles = mysqlTable("reconciliationFiles", {
  id: int("id").autoincrement().primaryKey(),
  batchId: int("batchId").notNull(),
  userId: int("userId").notNull(),
  fileName: varchar("fileName", { length: 512 }).notNull(),
  fileKey: varchar("fileKey", { length: 1024 }).notNull(),
  storageUrl: varchar("storageUrl", { length: 2048 }).notNull(),
  mimeType: varchar("mimeType", { length: 255 }).notNull(),
  byteSize: int("byteSize").notNull(),
  category: mysqlEnum("category", ["tabular", "document", "image", "media", "archive", "other"]).default("other").notNull(),
  status: mysqlEnum("fileStatus", ["stored", "invalid", "failed"]).default("stored").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ReconciliationBatch = typeof reconciliationBatches.$inferSelect;
export type ReconciliationFile = typeof reconciliationFiles.$inferSelect;
