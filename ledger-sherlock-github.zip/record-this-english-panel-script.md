# Record This: Ledger Sherlock Panel Pitch

**Estimated speaking time:** 4 minutes 45 seconds to 5 minutes 15 seconds at a calm pace.  
**Use:** Read only the quoted text aloud. Do not read the time labels or production notes.

## Before you record

Record in **landscape / horizontal mode**, at 1080p if possible. Keep the camera at eye level, face a window or a light source, and look at the camera when you begin each new section. Speak slowly and naturally; do not rush. Leave a one-second pause whenever the script says **[pause]**.

Your current vertical sample is clear, but its background includes a door, ceiling fan, and a reflection of another person. For the final recording, choose a plain wall or clean background and make sure no other person is visible. This will let the face-cam sit neatly beside the product screen.

> **Pronunciation help:** “Reconciliation” = *re-con-sil-ee-ay-shun*. “ERP” = *E-R-P*. “Razorpay” = *Razor-pay*.

---

## 0:00–0:35 — Opening and problem

> “Hello everyone. My name is Owais Khan, and I am presenting Ledger Sherlock. Ledger Sherlock is an explainable finance controller for settlement reconciliation. [pause]
>
> In a business, finance teams receive data from different places. They have a payment settlement report, a bank statement, and an ERP ledger. When these records do not match, the team has to spend a lot of time finding the reason. It can be a fee, GST, a refund, a delayed credit, a duplicate payment, or a missing entry. My project helps the team investigate these cases in a clear and controlled way.”

## 0:35–1:20 — Overview screen

> “This is the Overview screen. The main area is called the Evidence Command Canvas. It shows the complete flow from source data to final decision. [pause]
>
> On the left, we have three important sources: Razorpay settlement export, bank credits, and ERP ledger. In the middle, the Evidence Trace compares important details like transaction reference, amount, fee plus GST, and ledger value. This means the system does not give a black-box answer. It shows the evidence and the rule behind every decision. [pause]
>
> On the right side, there are two outcomes. Green means the record was safely cleared by deterministic rules. Orange means a human decision is still required. So, Ledger Sherlock automates safe cases, but it does not hide risky cases.”

## 1:20–2:15 — Reconciliation and measured proof

> “Now I click on Reconciliation. Here, I can see the settlement export, the bank-credit window, and the ERP ledger together. Then I click Run 60-Case Evaluation. [pause]
>
> This button runs a versioned synthetic evaluation dataset. It includes exact matches, fee and GST differences, refunds, timing delays, missing credits, duplicate settlements, and ambiguous cases. It is not a random or cherry-picked demo. [pause]
>
> During the run, the system seals the input evidence, applies deterministic finance rules, and prepares an audit result. After the run, it shows cases processed, source records, match rate, decision accuracy, false-positive auto closes, and time taken. [pause]
>
> In this built-in synthetic corpus, 60 cases and 174 source records are evaluated. Fifty-two cases are safely auto-closed, four timing cases are monitored, and four cases remain unresolved for human review. These are synthetic evaluation results, not claims about a real merchant.”

## 2:15–2:55 — Escalation packet and AI investigation

> “Below the scorecard, I can see the Honest Residual Queue. These are the cases that the system intentionally does not auto-close. When I click a case, I can open or download an escalation packet. It contains the evidence, the reason code, the recommended owner, and the next step. [pause]
>
> Then I can click Run Bounded AI Review. AI is used only after deterministic rules stop. It classifies the unresolved cases, gives an explanation, and cites the available evidence. But AI cannot move money, create a journal entry, or override a policy. Human approval is always required for sensitive actions.”

## 2:55–3:35 — Exceptions screen

> “Now I click Exceptions. This is the human decision queue. I can filter cases by fee variance, duplicate settlement, partial refund, or timing delay. I can also search by transaction ID. [pause]
>
> When I click any row, the case details open. The operator can compare Razorpay settlement data, bank statement data, and ERP expected value side by side. The screen also shows the AI explanation and the policy control. The goal is not only to show an alert. The goal is to give the finance person all the evidence needed to make the right decision.”

## 3:35–4:20 — Validation, Policy Engine, and Audit Trail

> “In Validation, I can review predicted and actual classifications. This is important because AI confidence and measured accuracy are different things. The measured reconciliation result is shown clearly in the 60-case proof loop. [pause]
>
> In Policy Engine, I define the safety boundaries. Low-value mismatches may be auto-resolved. Medium-value mismatches create a draft query, but a human must approve it before sending. High-value mismatches always go to human review. This is why Ledger Sherlock is built for safe automation, not blind automation. [pause]
>
> In Audit Trail, every action is traceable. We can see the source record, rule triggered, AI classification, human approval, user, and final status. This answers three important questions: what happened, why did it happen, and who approved it.”

## 4:20–5:00 — Data Sources, honest scope, and closing

> “In Data Sources, I can view the settlement, bank, and ERP inputs. I can click Upload New Dataset and choose or drag files into the secure upload flow. Actual storage requires sign-in, and file metadata is saved safely. [pause]
>
> At this stage, secure upload is live, but uploaded CSV files are not yet automatically parsed into the matching engine. I have kept this scope honest, because in finance, trust matters more than exaggerated claims. [pause]
>
> To conclude, Ledger Sherlock brings together evidence, deterministic reconciliation, bounded AI investigation, policy controls, human approvals, and a full audit trail. It is not just a finance chatbot. It is a controlled decision workspace that helps finance teams reconcile faster and with more confidence. Thank you.”

---

## Send this after recording

Upload the finished video in **horizontal landscape**, ideally one continuous 5-minute file. Speak the exact text above, keep the microphone close enough for clear audio, and do not add background music. Once you upload it, I will place your real face-cam on the side of the Ledger Sherlock screen walkthrough and synchronize it with the correct product view.
