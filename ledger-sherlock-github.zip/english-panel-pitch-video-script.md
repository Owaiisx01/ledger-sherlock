# Ledger Sherlock — Five-Minute English Panel Pitch

**Narration style:** conversational, confident, simple, and evidence-led.  
**Core message:** Ledger Sherlock is an explainable finance-control workflow, not an unbounded AI chatbot.  
**Accuracy note:** The measured 60-case evaluation is a versioned synthetic corpus. Secure upload storage is live after sign-in, but uploaded files are not yet automatically parsed into the matching engine.

## Part 1 — The problem and the control room

“Hello everyone. I am presenting Ledger Sherlock, an explainable settlement controller designed for finance operations.

Finance teams often work across three disconnected sources: the payment settlement export, the bank credit statement, and the ERP ledger. When values do not match, the team has to manually investigate the reason. It may be a payment-processing fee, GST on that fee, a refund, a delayed bank credit, a duplicate settlement, or a missing transaction. This process is slow, difficult to audit, and risky when automated systems make decisions without showing why.

Ledger Sherlock is built to solve that problem with evidence first.

We start on the Overview screen. The Evidence Command Canvas shows the three inputs: Razorpay settlement export, bank credits, and ERP ledger. In the center, the Evidence Trace makes the decision logic visible. It compares reference IDs, transaction amounts, fee plus GST calculations, and timing windows. Instead of saying that a record matched because an AI model decided so, the product shows the rule and the evidence used.

On the right, outcomes are separated into two groups. Green means safely cleared through deterministic rules. Orange means the record must be reviewed by a human. This is the core product principle: automate the safe cases, but never hide the risky ones.

When I click Run Controlled Match, I move into the Reconciliation workspace.”

## Part 2 — Reconciliation proof loop and bounded AI

“The Reconciliation workspace is where I demonstrate the finance-control loop.

At the top, there are three sources: settlement export, bank-credit window, and ERP ledger. I click Run 60-Case Evaluation. This runs Ledger Sherlock’s versioned synthetic evaluation corpus. It contains representative finance cases: exact matches, fee and GST differences, refunds, timing delays, missing credits, duplicate settlements, and ambiguous cases. It is not a cherry-picked list of easy transactions.

During the run, the interface shows that inputs are sealed, deterministic rules are being applied, and an audit result is being prepared. The result then reports clear measurements: cases processed, source records, deterministic match rate, decision accuracy against ground truth, false-positive auto closes, and elapsed time.

In the built-in synthetic corpus, 60 cases and 174 source records are evaluated. Fifty-two cases are safely auto-closed, four timing cases are monitored, and four cases intentionally remain unresolved. The deterministic auto-close rate is 86.7 percent, the ground-truth decision accuracy is 100 percent, and unsafe false-positive auto-resolution is zero. These are measured results from the synthetic corpus, not claims about a production merchant.

The remaining cases go to the Honest Residual Queue. I click one unresolved case, and the product prepares an escalation packet. This packet contains the evidence, the reason code, the recommended owner, and the next step. The finance team can download it as JSON and send a complete, structured case to the right reviewer.

Next, I click Run Bounded AI Review. AI is intentionally used after deterministic rules stop. It classifies only the residual cases, follows a fixed taxonomy, cites the available evidence, and cannot override policy. This is not an AI agent with permission to move money. It is an investigation assistant inside a controlled workflow.

In the AI Investigation tab, I can inspect the classification, confidence, explanation, and suggested action. A confidence click shows the evidence basis. The product also makes it clear that confidence is different from measured accuracy.”

## Part 3 — Exceptions, policies, auditability, and close

“Now I open Exceptions. This is the human decision queue. I can filter by fee variance, duplicate settlement, partial refund, or timing delay. I can search a transaction, and I can click any row to open the full case drawer.

The case drawer compares the Razorpay settlement, bank statement, and ERP expected value side by side. It adds the AI explanation, but most importantly it includes the policy control. The operator is not asked to trust the system blindly; the operator receives a complete evidence package before making a decision.

The Policy Engine defines those boundaries. Low-value mismatches may be auto-resolved. Medium-value mismatches create a draft query, but a human approves before sending. High-value mismatches always require human review. This is how Ledger Sherlock turns automation into safe automation.

The Audit Trail records the history of every case: the source record, rule triggered, AI classification, human approval, user, and final status. This gives the finance team a direct answer to three questions: what happened, why did it happen, and who approved it.

In Data Sources, I can see the settlement, bank, and ERP inputs. I can click Upload New Dataset and choose or drag files into the live secure intake. File bytes are stored only after sign-in and are persisted through managed storage with batch metadata. Today, the secure upload flow is live; automatic CSV parsing into the matching engine is the next extension, and we state that honestly.

Finally, Analytics gives the operating view of match quality, queue health, and exception categories. Settings controls merchant context, currency, timezone, and human-in-the-loop defaults.

To conclude, Ledger Sherlock is not trying to replace finance judgment with a black box. It connects evidence, deterministic reconciliation, bounded AI investigation, policy gates, human approvals, and an audit trail in one system. That is why it is designed as a finance controller, not just a finance chatbot. Thank you.”
